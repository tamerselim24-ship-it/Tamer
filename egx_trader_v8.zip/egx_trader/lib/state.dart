import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/data_source.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  AppState(this.source);

  final MarketDataSource source;
  List<Quote> quotes = const [];
  final Set<String> watchlist = {};

  /// أسهم ضافها المستخدم بنفسه (بتتحفظ على الجهاز).
  final List<String> extraSymbols = [];
  bool loading = false;
  String? error;
  DateTime? updatedAt;

  bool get isDemo => source.isDemo;
  String? get sourceError => source.lastError;

  /// تاريخ أحدث جلسة تداول في البيانات المعروضة.
  DateTime? get dataDate {
    DateTime? d;
    for (final q in quotes) {
      final a = q.asOf;
      if (a != null && (d == null || a.isAfter(d))) d = a;
    }
    return d;
  }

  static const _watchKey = 'watchlist';
  static const _extraKey = 'extra_symbols';

  /// آخر جلسة تداول المفروض تكون خلصت (الأحد–الخميس، الإغلاق 2:30، بنستنى لحد 3).
  /// ما بتعرفش الإجازات الرسمية.
  static DateTime expectedSession(DateTime now) {
    var d = DateTime(now.year, now.month, now.day);
    if (now.hour < 15) d = DateTime(d.year, d.month, d.day - 1);
    while (d.weekday == DateTime.friday || d.weekday == DateTime.saturday) {
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return d;
  }

  /// رسالة تحذير لو البيانات أقدم من آخر جلسة متوقعة، وإلا null.
  String? get staleMessage {
    final d = dataDate;
    if (isDemo || d == null) return null;
    final exp = expectedSession(DateTime.now());
    final have = DateTime(d.year, d.month, d.day);
    if (!have.isBefore(exp)) return null;
    String f(DateTime x) =>
        "${x.day.toString().padLeft(2, "0")}/${x.month.toString().padLeft(2, "0")}";
    return 'الأسعار لجلسة ${f(have)}، وجلسة ${f(exp)} لسه ما نزلتش من ياهو '
        '(بيتأخر عادةً يوم). ممكن تكون إجازة.';
  }

  Future<void> init() async {
    try {
      final p = await SharedPreferences.getInstance();
      watchlist.addAll(p.getStringList(_watchKey) ?? const []);
      extraSymbols.addAll(p.getStringList(_extraKey) ?? const []);
    } catch (_) {}
    await refresh();
  }

  Future<void> refresh() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final base = await source.fetchQuotes();
      final have = base.map((q) => q.symbol).toSet();
      final extras = await Future.wait(extraSymbols
          .where((s) => !have.contains(s))
          .map((s) async {
        try {
          return await source.lookup(s);
        } catch (_) {
          return null;
        }
      }));
      quotes = [...base, ...extras.whereType<Quote>()];
      updatedAt = DateTime.now();
    } catch (e) {
      error = 'تعذّر تحميل الأسعار: $e';
    }
    loading = false;
    notifyListeners();
  }

  /// يرجّع null لو نجحت الإضافة، أو رسالة الخطأ.
  Future<String?> addSymbol(String raw) async {
    final s = raw.trim().toUpperCase().replaceAll('.CA', '');
    if (s.isEmpty) return 'اكتب رمز السهم';
    if (quotes.any((q) => q.symbol == s)) return 'السهم موجود بالفعل في القايمة';
    try {
      final q = await source.lookup(s);
      if (q == null) return 'مفيش سهم بالرمز "$s" على المصدر';
      quotes = [...quotes, q];
      extraSymbols.add(s);
      notifyListeners();
      await _save();
      return null;
    } catch (e) {
      return 'تعذّر الجلب، اتأكد من الإنترنت ($e)';
    }
  }

  bool isExtra(String symbol) => extraSymbols.contains(symbol);

  Future<void> removeSymbol(String symbol) async {
    if (!extraSymbols.remove(symbol)) return;
    watchlist.remove(symbol);
    quotes = quotes.where((q) => q.symbol != symbol).toList();
    notifyListeners();
    await _save();
  }

  Future<void> toggleWatch(String symbol) async {
    if (!watchlist.remove(symbol)) watchlist.add(symbol);
    notifyListeners();
    await _save();
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList(_watchKey, watchlist.toList());
      await p.setStringList(_extraKey, extraSymbols);
    } catch (_) {}
  }
}
