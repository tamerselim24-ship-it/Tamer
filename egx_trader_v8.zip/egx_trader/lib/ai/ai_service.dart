import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'prompt.dart';

class AiException implements Exception {
  const AiException(this.message, {this.needsKey = false});
  final String message;

  /// true لو المشكلة في المفتاح (مفقود أو غلط) فنعرض زرار الإعدادات.
  final bool needsKey;

  @override
  String toString() => message;
}

enum AiProvider { claude, gemini }

/// نداء مباشر لخدمة الذكاء الاصطناعي من الموبايل بمفتاح المستخدم نفسه.
/// المفاتيح بتتحفظ على الجهاز بس، ومش متضمّنة في الـ APK.
class AiService {
  static const _providerPref = 'ai_provider';
  static const _claudeKeyPref = 'anthropic_api_key';
  static const _claudeModelPref = 'ai_model';
  static const _geminiKeyPref = 'gemini_api_key';
  static const _geminiModelPref = 'gemini_model';

  static const defaultClaudeModel = 'claude-sonnet-5-5';

  /// alias بيشاور على أحدث Flash. لو جوجل غيّرته، غيّر الاسم من الإعدادات.
  static const defaultGeminiModel = 'gemini-flash-latest';

  static const claudeModels = <String, String>{
    'claude-sonnet-5-5': 'Sonnet 5.5 (متوازن)',
    'claude-haiku-5-5': 'Haiku 5.5 (أسرع وأرخص)',
    'claude-opus-5-5': 'Opus 5.5 (الأقوى)',
  };

  static Future<SharedPreferences?> _prefs() async {
    try {
      return await SharedPreferences.getInstance();
    } catch (_) {
      return null;
    }
  }

  static Future<AiProvider> getProvider() async {
    final p = await _prefs();
    return p?.getString(_providerPref) == 'gemini' ? AiProvider.gemini : AiProvider.claude;
  }

  static Future<void> setProvider(AiProvider v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_providerPref, v.name);
  }

  static String _keyPref(AiProvider v) =>
      v == AiProvider.gemini ? _geminiKeyPref : _claudeKeyPref;

  static String _modelPref(AiProvider v) =>
      v == AiProvider.gemini ? _geminiModelPref : _claudeModelPref;

  static Future<String?> getKey(AiProvider v) async {
    final p = await _prefs();
    final k = p?.getString(_keyPref(v));
    return (k == null || k.trim().isEmpty) ? null : k.trim();
  }

  static Future<void> setKey(AiProvider v, String key) async {
    final p = await SharedPreferences.getInstance();
    if (key.trim().isEmpty) {
      await p.remove(_keyPref(v));
    } else {
      await p.setString(_keyPref(v), key.trim());
    }
  }

  static Future<String> getModel(AiProvider v) async {
    final p = await _prefs();
    final m = p?.getString(_modelPref(v))?.trim();
    if (v == AiProvider.gemini) {
      return (m == null || m.isEmpty) ? defaultGeminiModel : m;
    }
    return (m != null && claudeModels.containsKey(m)) ? m : defaultClaudeModel;
  }

  static Future<void> setModel(AiProvider v, String model) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_modelPref(v), model.trim());
  }

  static Future<String> analyze(String prompt) async {
    final provider = await getProvider();
    final key = await getKey(provider);
    final name = provider == AiProvider.gemini ? 'Gemini' : 'Claude';
    if (key == null) {
      throw AiException(
        'محتاج مفتاح $name API الأول. افتح الإعدادات وحطه.',
        needsKey: true,
      );
    }
    final model = await getModel(provider);
    return provider == AiProvider.gemini
        ? _gemini(prompt, key, model)
        : _claude(prompt, key, model);
  }

  // ───────────── مشترك ─────────────

  static Future<Map<String, dynamic>> _post(
    Uri uri,
    Map<String, String> headers,
    Map<String, dynamic> body,
    String who,
  ) async {
    final http.Response res;
    try {
      res = await http
          .post(uri, headers: headers, body: jsonEncode(body))
          .timeout(const Duration(seconds: 90));
    } catch (e) {
      throw AiException('تعذّر الاتصال بخدمة $who. اتأكد من الإنترنت. ($e)');
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw AiException('رد غير مفهوم من $who (HTTP ${res.statusCode})');
    }

    if (res.statusCode != 200) {
      final err = data['error'];
      final msg = '${(err is Map ? err['message'] : null) ?? 'HTTP ${res.statusCode}'}';
      final badKey = res.statusCode == 401 ||
          res.statusCode == 403 ||
          (res.statusCode == 400 && msg.toLowerCase().contains('api key'));
      if (badKey) throw AiException('المفتاح مرفوض: $msg', needsKey: true);
      throw AiException('خطأ من $who (${res.statusCode}): $msg');
    }
    return data;
  }

  // ───────────── Claude ─────────────

  static Future<String> _claude(String prompt, String key, String model) async {
    final data = await _post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      {
        'model': model,
        'max_tokens': 2000,
        'system': aiSystemPrompt,
        'messages': [
          {'role': 'user', 'content': prompt},
        ],
      },
      'Claude',
    );
    final parts = (data['content'] as List?) ?? const [];
    final text = parts
        .whereType<Map>()
        .where((p) => p['type'] == 'text')
        .map((p) => '${p['text']}')
        .join('\n')
        .trim();
    if (text.isEmpty) throw const AiException('الخدمة رجّعت رد فاضي، جرّب تاني.');
    return text;
  }

  // ───────────── Gemini ─────────────

  static Future<String> _gemini(String prompt, String key, String model) async {
    final data = await _post(
      Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'),
      {
        'x-goog-api-key': key,
        'content-type': 'application/json',
      },
      {
        'systemInstruction': {
          'parts': [
            {'text': aiSystemPrompt},
          ],
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': prompt},
            ],
          },
        ],
        // الموديلات الجديدة بتحسب "التفكير" ضمن الحد، فنديها مساحة كبيرة.
        'generationConfig': {'maxOutputTokens': 6000},
      },
      'Gemini',
    );
    final cands = (data['candidates'] as List?) ?? const [];
    if (cands.isEmpty) {
      throw const AiException('Gemini ما رجّعش رد (ممكن اتحجب). جرّب تاني.');
    }
    final first = cands.first;
    final content = first is Map ? first['content'] : null;
    final rawParts = content is Map ? content['parts'] : null;
    final parts = rawParts is List ? rawParts : const [];
    final text = parts
        .whereType<Map>()
        .map((p) => '${p['text'] ?? ''}')
        .join('\n')
        .trim();
    if (text.isEmpty) throw const AiException('الخدمة رجّعت رد فاضي، جرّب تاني.');
    return text;
  }
}
