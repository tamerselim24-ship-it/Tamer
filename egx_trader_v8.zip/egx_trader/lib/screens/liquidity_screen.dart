import 'package:flutter/material.dart';

import '../models.dart';
import '../util.dart';

/// ترتيب السوق حسب قيمة التداول (السيولة) مع نسبة كل سهم من إجمالي السوق.
class LiquidityView extends StatelessWidget {
  const LiquidityView({super.key, required this.quotes, required this.onTap});
  final List<Quote> quotes;
  final void Function(Quote) onTap;

  @override
  Widget build(BuildContext context) {
    final sorted = [...quotes]..sort((a, b) => b.value.compareTo(a.value));
    final total = sorted.fold<double>(0, (a, q) => a + q.value);
    final maxV = sorted.isEmpty ? 1.0 : sorted.first.value;
    final up = quotes.where((q) => q.change > 0).length;
    final down = quotes.where((q) => q.change < 0).length;

    return ListView(children: [
      Card(
        margin: const EdgeInsets.all(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _stat('إجمالي السيولة', '${fmtCompact(total)} ج.م'),
            _stat('صاعد', '$up', color: Colors.green),
            _stat('هابط', '$down', color: Colors.red),
          ]),
        ),
      ),
      for (final q in sorted)
        ListTile(
          onTap: () => onTap(q),
          title: Row(children: [
            Text(q.symbol, style: const TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            Text('${fmtCompact(q.value)} ج.م'),
          ]),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Row(children: [
              Expanded(
                child: LinearProgressIndicator(
                  value: maxV == 0 ? 0 : q.value / maxV,
                  minHeight: 6,
                  color: changeColor(q.change),
                ),
              ),
              const SizedBox(width: 8),
              Text('${fmtNum(total == 0 ? 0 : q.value / total * 100, 1)}%',
                  style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ),
    ]);
  }

  Widget _stat(String label, String value, {Color? color}) => Column(children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
      ]);
}
