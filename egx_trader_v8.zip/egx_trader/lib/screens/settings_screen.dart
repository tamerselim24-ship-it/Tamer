import 'package:flutter/material.dart';

import '../ai/ai_service.dart';
import '../util.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _claudeKey = TextEditingController();
  final _geminiKey = TextEditingController();
  final _geminiModel = TextEditingController();
  AiProvider _provider = AiProvider.claude;
  String _claudeModel = AiService.defaultClaudeModel;
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final provider = await AiService.getProvider();
    final ck = await AiService.getKey(AiProvider.claude);
    final gk = await AiService.getKey(AiProvider.gemini);
    final cm = await AiService.getModel(AiProvider.claude);
    final gm = await AiService.getModel(AiProvider.gemini);
    if (!mounted) return;
    setState(() {
      _provider = provider;
      _claudeKey.text = ck ?? '';
      _geminiKey.text = gk ?? '';
      _claudeModel = cm;
      _geminiModel.text = gm;
    });
  }

  @override
  void dispose() {
    _claudeKey.dispose();
    _geminiKey.dispose();
    _geminiModel.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await AiService.setProvider(_provider);
    await AiService.setKey(AiProvider.claude, _claudeKey.text);
    await AiService.setKey(AiProvider.gemini, _geminiKey.text);
    await AiService.setModel(AiProvider.claude, _claudeModel);
    await AiService.setModel(AiProvider.gemini, _geminiModel.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ')));
    Navigator.pop(context);
  }

  InputDecoration _keyDecoration(String label, String hint) => InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        suffixIcon: IconButton(
          icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
          onPressed: () => setState(() => _hide = !_hide),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final gemini = _provider == AiProvider.gemini;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('التحليل بالذكاء الاصطناعي',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SegmentedButton<AiProvider>(
          segments: const [
            ButtonSegment(value: AiProvider.gemini, label: Text('Gemini (مجاني)')),
            ButtonSegment(value: AiProvider.claude, label: Text('Claude (مدفوع)')),
          ],
          selected: {_provider},
          onSelectionChanged: (s) => setState(() => _provider = s.first),
        ),
        const SizedBox(height: 16),
        if (gemini) ...[
          TextField(
            controller: _geminiKey,
            obscureText: _hide,
            textDirection: TextDirection.ltr,
            autocorrect: false,
            enableSuggestions: false,
            decoration: _keyDecoration('مفتاح Gemini API', 'AIza...'),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _geminiModel,
            textDirection: TextDirection.ltr,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'اسم الموديل',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'لو ظهر خطأ "model not found" غيّر الاسم لأي موديل متاح في aistudio.google.com.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          const Text(
            'خد المفتاح من aistudio.google.com (زرار Get API key). فيه خطة مجانية بحدود '
            'استخدام. في الخطة المجانية ممكن جوجل تستخدم البيانات المبعوتة لتحسين موديلاتها '
            '(وإحنا بنبعت أرقام أسهم بس).',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ] else ...[
          TextField(
            controller: _claudeKey,
            obscureText: _hide,
            textDirection: TextDirection.ltr,
            autocorrect: false,
            enableSuggestions: false,
            decoration: _keyDecoration('مفتاح Anthropic API', 'sk-ant-...'),
          ),
          const SizedBox(height: 16),
          const Text('الموديل'),
          DropdownButton<String>(
            isExpanded: true,
            value: _claudeModel,
            items: [
              for (final e in AiService.claudeModels.entries)
                DropdownMenuItem(value: e.key, child: Text(e.value)),
            ],
            onChanged: (v) => setState(() => _claudeModel = v ?? _claudeModel),
          ),
          const SizedBox(height: 16),
          const Text(
            'خد المفتاح من console.anthropic.com (قسم API Keys). حساب الـ API منفصل '
            'عن اشتراك تطبيق Claude، وبيتحاسب على قد الاستخدام ومحتاج رصيد.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
        const SizedBox(height: 16),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
        const SizedBox(height: 24),
        const Text(
          'المفاتيح بتتحفظ على موبايلك بس، ومش بتتبعت لأي مكان غير الخدمة اللي اخترتها.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 16),
        const Text('إصدار التطبيق: $kAppVersion',
            style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    );
  }
}
