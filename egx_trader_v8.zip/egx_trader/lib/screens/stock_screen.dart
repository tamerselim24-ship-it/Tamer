import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../ai/ai_service.dart';
import '../ai/prompt.dart';
import '../analysis/fundamental.dart';
import '../analysis/liquidity.dart';
import '../analysis/technical.dart';
import '../data/data_source.dart';
import '../models.dart';
import '../util.dart';
import '../widgets/charts.dart';
import 'settings_screen.dart';

Color _verdictColor(Verdict v) => switch (v) {
      Verdict.buy => Colors.green,
      Verdict.sell => Colors.red,
      Verdict.neutral => Colors.grey,
    };

IconData _verdictIcon(Verdict v) => switch (v) {
      Verdict.buy => Icons.trending_up,
      Verdict.sell => Icons.trending_down,
      Verdict.neutral => Icons.remove,
    };

class StockScreen extends StatefulWidget {
  const StockScreen({super.key, required this.quote, required this.source});
  final Quote quote;
  final MarketDataSource source;

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  late final Future<List<Candle>> _hist = widget.source.fetchHistory(widget.quote.symbol);
  late final Future<Fundamentals?> _fund = widget.source.fetchFundamentals(widget.quote.symbol);

  @override
  Widget build(BuildContext context) {
    final q = widget.quote;
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: Text('${q.symbol} • ${q.name}'),
          bottom: const TabBar(isScrollable: true, tabs: [
            Tab(text: 'فني'),
            Tab(text: 'مالي'),
            Tab(text: 'سيولة'),
            Tab(text: 'AI'),
            Tab(text: 'مباشر'),
          ]),
        ),
        body: Column(children: [
          _header(q),
          Expanded(
            // التنقل بين التبويبات بالضغط بس، علشان سحب الشارت ما يغيّرش التبويب.
            child: TabBarView(physics: const NeverScrollableScrollPhysics(), children: [
              _histTab((c) => _TechnicalTab(candles: c)),
              _FundamentalTab(quote: q, future: _fund),
              _histTab((c) => _LiquidityTab(candles: c, quote: q)),
              _AiTab(quote: q, hist: _hist, fund: _fund, isDemo: widget.source.isDemo),
              _LiveTab(symbol: q.symbol),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _histTab(Widget Function(List<Candle>) build) {
    return FutureBuilder<List<Candle>>(
      future: _hist,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError || snap.data == null || snap.data!.isEmpty) {
          return const Center(child: Text('تعذّر تحميل السجل التاريخي'));
        }
        return build(snap.data!);
      },
    );
  }

  Widget _header(Quote q) {
    final color = changeColor(q.change);
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(fmtNum(q.last), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(width: 10),
          Text('${fmtNum(q.change)}  (${fmtPct(q.changePct)})',
              style: TextStyle(color: color, fontSize: 16)),
        ]),
        if (q.asOf != null)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              'أرقام جلسة '
              '${q.asOf!.day.toString().padLeft(2, "0")}/${q.asOf!.month.toString().padLeft(2, "0")}'
              ' من ياهو. تبويب "مباشر" أحدث.',
              style: const TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ),
        const SizedBox(height: 6),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _kv('فتح', fmtNum(q.open)),
          _kv('أعلى', fmtNum(q.high)),
          _kv('أدنى', fmtNum(q.low)),
          _kv('إغلاق سابق', fmtNum(q.prevClose)),
        ]),
      ]),
    );
  }

  Widget _kv(String k, String v) => Column(children: [
        Text(k, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        Text(v, style: const TextStyle(fontSize: 13)),
      ]);
}

// ───────────── فني ─────────────

class _TechnicalTab extends StatelessWidget {
  const _TechnicalTab({required this.candles});
  final List<Candle> candles;

  @override
  Widget build(BuildContext context) {
    final closes = [for (final c in candles) c.close];
    final sma20 = sma(closes, 20), sma50 = sma(closes, 50), sma200 = sma(closes, 200);
    final bb = bollinger(closes);
    final r = rsi(closes);
    final m = macd(closes);
    final summary = analyzeTechnical(candles);
    final levels = pivotLevels(candles);

    return ListView(padding: const EdgeInsets.all(12), children: [
      Card(
        child: ListTile(
          title: Text('الاتجاه العام: ${summary.overall}'),
          subtitle: Text('شراء ${summary.buy} • بيع ${summary.sell} • محايد ${summary.neutral}'),
        ),
      ),
      const SizedBox(height: 8),
      const Wrap(children: [
        LegendDot(Colors.white, 'السعر'),
        LegendDot(Colors.orange, 'SMA20'),
        LegendDot(Colors.lightGreen, 'SMA50'),
        LegendDot(Colors.purpleAccent, 'SMA200'),
        LegendDot(Colors.blueGrey, 'بولينجر'),
      ]),
      MultiLineChart(series: [
        LineSeries(bb.upper, Colors.blueGrey, width: 1, dashed: true),
        LineSeries(bb.lower, Colors.blueGrey, width: 1, dashed: true),
        LineSeries(sma200, Colors.purpleAccent, width: 1.2),
        LineSeries(sma50, Colors.lightGreen, width: 1.2),
        LineSeries(sma20, Colors.orange, width: 1.2),
        LineSeries(closes, Colors.white, width: 1.8),
      ]),
      const SizedBox(height: 12),
      const Text('RSI (14)'),
      MultiLineChart(
        height: 100,
        minY: 0,
        maxY: 100,
        guides: const [30, 70],
        series: [LineSeries(r, Colors.cyanAccent)],
      ),
      const SizedBox(height: 12),
      const Text('MACD (Histogram)'),
      MiniBars(
        values: m.hist,
        colors: [for (final h in m.hist) (h ?? 0) >= 0 ? Colors.green : Colors.red],
      ),
      const SizedBox(height: 12),
      if (levels.support.isNotEmpty || levels.resistance.isNotEmpty)
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('الدعم والمقاومة', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('مقاومة: ${levels.resistance.map(fmtNum).join(' • ')}'),
              Text('دعم: ${levels.support.map(fmtNum).join(' • ')}'),
            ]),
          ),
        ),
      const SizedBox(height: 8),
      for (final s in summary.signals)
        ListTile(
          dense: true,
          leading: Icon(_verdictIcon(s.verdict), color: _verdictColor(s.verdict)),
          title: Text(s.name),
          subtitle: Text(s.detail),
        ),
      const _Disclaimer(),
    ]);
  }
}

// ───────────── مالي ─────────────

class _FundamentalTab extends StatelessWidget {
  const _FundamentalTab({required this.quote, required this.future});
  final Quote quote;
  final Future<Fundamentals?> future;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Fundamentals?>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final f = snap.data;
        if (snap.hasError || f == null) {
          return const Center(child: Text('البيانات المالية غير متاحة لهذا السهم'));
        }
        final ratios = analyzeFundamentals(quote, f);
        return ListView(padding: const EdgeInsets.all(12), children: [
          if (f.revenue != null || f.netProfit != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  if (f.revenue != null) _stat('الإيرادات', fmtCompact(f.revenue!)),
                  if (f.netProfit != null) _stat('صافي الربح', fmtCompact(f.netProfit!)),
                  if (f.eps != null) _stat('EPS', fmtNum(f.eps!)),
                ]),
              ),
            ),
          for (final r in ratios)
            ListTile(
              leading: Icon(_verdictIcon(r.verdict), color: _verdictColor(r.verdict)),
              title: Text(r.name),
              subtitle: r.note.isEmpty ? null : Text(r.note),
              trailing: Text(r.value, style: const TextStyle(fontSize: 16)),
            ),
          const _Disclaimer(),
        ]);
      },
    );
  }

  Widget _stat(String k, String v) => Column(children: [
        Text(k, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        Text(v, style: const TextStyle(fontWeight: FontWeight.bold)),
      ]);
}

// ───────────── سيولة ─────────────

class _LiquidityTab extends StatelessWidget {
  const _LiquidityTab({required this.candles, required this.quote});
  final List<Candle> candles;
  final Quote quote;

  @override
  Widget build(BuildContext context) {
    final st = analyzeLiquidity(candles);
    final vols = [for (final c in candles) c.volume];
    final colors = [for (final c in candles) c.close >= c.open ? Colors.green : Colors.red];
    final o = obv(candles);

    return ListView(padding: const EdgeInsets.all(12), children: [
      if (st != null)
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(st.activity, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('حجم اليوم: ${fmtCompact(quote.volume)} سهم'),
              Text('قيمة التداول: ${fmtCompact(quote.value)} ج.م'),
              Text('متوسط الحجم (20 يوم): ${fmtCompact(st.avgVolume20)}'),
              Text('متوسط قيمة التداول (20 يوم): ${fmtCompact(st.avgValue20)} ج.م'),
              Text('الحجم ÷ المتوسط: ${fmtNum(st.volumeRatio)}x'),
              if (st.mfi != null) Text('MFI (14): ${fmtNum(st.mfi!, 1)}'),
              Text(st.obvRising
                  ? 'OBV: فوق متوسطه → تجميع'
                  : 'OBV: تحت متوسطه → تصريف'),
            ]),
          ),
        ),
      const SizedBox(height: 12),
      const Text('حجم التداول'),
      MiniBars(values: vols, colors: colors, height: 120),
      const SizedBox(height: 12),
      const Text('OBV'),
      MultiLineChart(height: 120, series: [LineSeries(o, Colors.tealAccent)]),
      const _Disclaimer(),
    ]);
  }
}

// ───────────── مباشر (TradingView) ─────────────

/// شارت TradingView الرسمي (Advanced Chart widget) داخل WebView.
/// ما اتجرّبش: مش مضمون إن TradingView بيعرض أسهم EGX في الـ widget المجاني.
class _LiveTab extends StatefulWidget {
  const _LiveTab({required this.symbol});
  final String symbol;

  @override
  State<_LiveTab> createState() => _LiveTabState();
}

class _LiveTabState extends State<_LiveTab> with AutomaticKeepAliveClientMixin {
  late final WebViewController _controller;

  @override
  bool get wantKeepAlive => true;

  String get _safe => widget.symbol.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '');

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF131722))
      ..loadHtmlString(_html(_safe), baseUrl: 'https://www.tradingview.com');
  }

  static String _html(String symbol) => '''
<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>html,body{margin:0;padding:0;height:100%;background:#131722;}</style></head>
<body>
<div class="tradingview-widget-container" style="height:100%;width:100%">
  <div class="tradingview-widget-container__widget" style="height:calc(100% - 24px);width:100%"></div>
  <div class="tradingview-widget-copyright" style="font-size:11px;text-align:center;height:24px;line-height:24px"><a href="https://www.tradingview.com/symbols/EGX-$symbol/" rel="noopener nofollow" target="_blank" style="color:#2962ff;text-decoration:none">$symbol on TradingView</a></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
  {"autosize": true, "symbol": "EGX:$symbol", "interval": "D", "timezone": "Africa/Cairo", "theme": "dark", "style": "1", "locale": "ar_AE", "allow_symbol_change": false, "hide_side_toolbar": true, "withdateranges": true, "support_host": "https://www.tradingview.com"}
  </script>
</div></body></html>
''';

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final url = 'https://www.tradingview.com/chart/?symbol=EGX%3A$_safe';
    return Column(children: [
      Expanded(
        child: WebViewWidget(controller: _controller),
      ),
      Padding(
        padding: const EdgeInsets.all(8),
        child: SelectableText(
          'لو الشارت ما ظهرش أو ظهرت رسالة، افتح الرابط ده في المتصفح:\n$url',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 11, color: Colors.grey),
        ),
      ),
    ]);
  }
}

// ───────────── ذكاء اصطناعي ─────────────

class _AiTab extends StatefulWidget {
  const _AiTab({
    required this.quote,
    required this.hist,
    required this.fund,
    required this.isDemo,
  });
  final Quote quote;
  final Future<List<Candle>> hist;
  final Future<Fundamentals?> fund;
  final bool isDemo;

  @override
  State<_AiTab> createState() => _AiTabState();
}

class _AiTabState extends State<_AiTab> with AutomaticKeepAliveClientMixin {
  String? _result;
  String? _error;
  bool _needsKey = false;
  bool _busy = false;

  @override
  bool get wantKeepAlive => true;

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _error = null;
      _needsKey = false;
    });
    try {
      final candles = await widget.hist;
      Fundamentals? f;
      try {
        f = await widget.fund;
      } catch (_) {}
      final prompt = buildAnalysisPrompt(
        quote: widget.quote,
        candles: candles,
        fundamentals: f,
        isDemo: widget.isDemo,
      );
      final text = await AiService.analyze(prompt);
      if (!mounted) return;
      setState(() => _result = text);
    } on AiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _needsKey = e.needsKey;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر التحليل: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ListView(padding: const EdgeInsets.all(12), children: [
      FilledButton.icon(
        onPressed: _busy ? null : _run,
        icon: const Icon(Icons.auto_awesome),
        label: Text(_result == null ? 'حلّل ${widget.quote.symbol} بالذكاء الاصطناعي' : 'حلّل من جديد'),
      ),
      if (_busy)
        const Padding(
          padding: EdgeInsets.only(top: 12),
          child: LinearProgressIndicator(),
        ),
      if (_error != null) ...[
        const SizedBox(height: 12),
        Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        if (_needsKey)
          TextButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
            ),
            icon: const Icon(Icons.settings),
            label: const Text('افتح الإعدادات'),
          ),
      ],
      if (_result != null) ...[
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: SelectableText(_result!, style: const TextStyle(height: 1.6)),
          ),
        ),
      ],
      const _Disclaimer(),
    ]);
  }
}

class _Disclaimer extends StatelessWidget {
  const _Disclaimer();

  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          'التحليل آلي ومبني على قواعد عامة، وليس توصية استثمارية. راجع مستشارًا مرخّصًا قبل أي قرار.',
          style: TextStyle(fontSize: 11, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
      );
}
