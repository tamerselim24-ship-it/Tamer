import '../analysis/technical.dart' show Verdict;
import '../models.dart';
import '../util.dart';

class Ratio {
  const Ratio(this.name, this.value, this.note, this.verdict);
  final String name;
  final String value;
  final String note;
  final Verdict verdict;
}

/// قواعد عامة مبسّطة. الحدود دي بتختلف من قطاع لقطاع، فاعتبرها نقطة بداية مش حكم نهائي.
List<Ratio> analyzeFundamentals(Quote q, Fundamentals f) {
  final out = <Ratio>[];
  final price = q.last;

  if (f.eps != null && f.eps! > 0) {
    final pe = price / f.eps!;
    out.add(Ratio(
      'مكرر الربحية P/E',
      fmtNum(pe),
      pe < 8 ? 'رخيص نسبيًا' : (pe > 20 ? 'مرتفع نسبيًا' : 'متوسط'),
      pe < 8 ? Verdict.buy : (pe > 20 ? Verdict.sell : Verdict.neutral),
    ));
  } else if (f.eps != null) {
    out.add(const Ratio('مكرر الربحية P/E', '—', 'الشركة خاسرة (EPS سالب)', Verdict.sell));
  }

  if (f.bookValuePerShare != null && f.bookValuePerShare! > 0) {
    final pb = price / f.bookValuePerShare!;
    out.add(Ratio(
      'السعر / القيمة الدفترية P/B',
      fmtNum(pb),
      pb < 1 ? 'يتداول تحت القيمة الدفترية' : (pb > 3 ? 'مرتفع' : 'معقول'),
      pb < 1 ? Verdict.buy : (pb > 3 ? Verdict.sell : Verdict.neutral),
    ));
  }

  if (f.dividendPerShare != null && price > 0) {
    final y = f.dividendPerShare! / price * 100;
    out.add(Ratio(
      'عائد التوزيعات',
      '${fmtNum(y)}%',
      y >= 5 ? 'عائد جيد' : (y == 0 ? 'لا توزيعات' : 'عائد منخفض'),
      y >= 5 ? Verdict.buy : Verdict.neutral,
    ));
  }

  if (f.netProfit != null && f.totalEquity != null && f.totalEquity! > 0) {
    final roe = f.netProfit! / f.totalEquity! * 100;
    out.add(Ratio(
      'العائد على حقوق الملكية ROE',
      '${fmtNum(roe)}%',
      roe >= 15 ? 'ربحية قوية' : (roe < 8 ? 'ربحية ضعيفة' : 'ربحية مقبولة'),
      roe >= 15 ? Verdict.buy : (roe < 8 ? Verdict.sell : Verdict.neutral),
    ));
  }

  if (f.netProfit != null && f.revenue != null && f.revenue! > 0) {
    final m = f.netProfit! / f.revenue! * 100;
    out.add(Ratio(
      'هامش صافي الربح',
      '${fmtNum(m)}%',
      m >= 15 ? 'هامش مرتفع' : (m < 5 ? 'هامش منخفض' : 'هامش متوسط'),
      m >= 15 ? Verdict.buy : (m < 5 ? Verdict.sell : Verdict.neutral),
    ));
  }

  if (f.totalDebt != null && f.totalEquity != null && f.totalEquity! > 0) {
    final de = f.totalDebt! / f.totalEquity!;
    out.add(Ratio(
      'الدين / حقوق الملكية',
      fmtNum(de),
      de < 0.5 ? 'مديونية منخفضة' : (de > 1.5 ? 'مديونية عالية' : 'مديونية متوسطة'),
      de < 0.5 ? Verdict.buy : (de > 1.5 ? Verdict.sell : Verdict.neutral),
    ));
  }

  if (f.revenueGrowthPct != null) {
    final g = f.revenueGrowthPct!;
    out.add(Ratio(
      'نمو الإيرادات',
      fmtPct(g),
      g >= 10 ? 'نمو جيد' : (g < 0 ? 'انكماش' : 'نمو بطيء'),
      g >= 10 ? Verdict.buy : (g < 0 ? Verdict.sell : Verdict.neutral),
    ));
  }

  if (f.sharesOutstanding != null) {
    out.add(Ratio(
      'القيمة السوقية',
      '${fmtCompact(price * f.sharesOutstanding!)} ج.م',
      '',
      Verdict.neutral,
    ));
  }
  return out;
}
