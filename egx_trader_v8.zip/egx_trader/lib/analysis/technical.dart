import 'dart:math';

import '../models.dart';

// ───────────── مؤشرات أساسية ─────────────

List<double?> sma(List<double> v, int n) {
  final out = List<double?>.filled(v.length, null);
  double sum = 0;
  for (var i = 0; i < v.length; i++) {
    sum += v[i];
    if (i >= n) sum -= v[i - n];
    if (i >= n - 1) out[i] = sum / n;
  }
  return out;
}

List<double?> ema(List<double> v, int n) {
  final out = List<double?>.filled(v.length, null);
  if (v.length < n) return out;
  final k = 2 / (n + 1);
  var prev = v.take(n).reduce((a, b) => a + b) / n;
  out[n - 1] = prev;
  for (var i = n; i < v.length; i++) {
    prev = v[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

double _rsiValue(double gain, double loss) =>
    loss == 0 ? 100 : 100 - 100 / (1 + gain / loss);

/// RSI بطريقة Wilder.
List<double?> rsi(List<double> v, [int n = 14]) {
  final out = List<double?>.filled(v.length, null);
  if (v.length <= n) return out;
  double gain = 0, loss = 0;
  for (var i = 1; i <= n; i++) {
    final d = v[i] - v[i - 1];
    if (d >= 0) {
      gain += d;
    } else {
      loss -= d;
    }
  }
  gain /= n;
  loss /= n;
  out[n] = _rsiValue(gain, loss);
  for (var i = n + 1; i < v.length; i++) {
    final d = v[i] - v[i - 1];
    gain = (gain * (n - 1) + (d > 0 ? d : 0)) / n;
    loss = (loss * (n - 1) + (d < 0 ? -d : 0)) / n;
    out[i] = _rsiValue(gain, loss);
  }
  return out;
}

class MacdResult {
  const MacdResult(this.line, this.signal, this.hist);
  final List<double?> line, signal, hist;
}

MacdResult macd(List<double> v, {int fast = 12, int slow = 26, int sig = 9}) {
  final nulls = List<double?>.filled(v.length, null);
  if (v.length < slow + sig) return MacdResult(nulls, nulls, nulls);
  final f = ema(v, fast), s = ema(v, slow);
  final line = List<double?>.filled(v.length, null);
  for (var i = 0; i < v.length; i++) {
    if (f[i] != null && s[i] != null) line[i] = f[i]! - s[i]!;
  }
  final start = slow - 1;
  final valid = <double>[for (var i = start; i < v.length; i++) line[i]!];
  final sg = ema(valid, sig);
  final signal = List<double?>.filled(v.length, null);
  final hist = List<double?>.filled(v.length, null);
  for (var j = 0; j < valid.length; j++) {
    final x = sg[j];
    if (x != null) {
      signal[start + j] = x;
      hist[start + j] = line[start + j]! - x;
    }
  }
  return MacdResult(line, signal, hist);
}

class Bands {
  const Bands(this.upper, this.mid, this.lower);
  final List<double?> upper, mid, lower;
}

Bands bollinger(List<double> v, {int n = 20, double k = 2}) {
  final mid = sma(v, n);
  final up = List<double?>.filled(v.length, null);
  final lo = List<double?>.filled(v.length, null);
  for (var i = n - 1; i < v.length; i++) {
    final m = mid[i]!;
    var sq = 0.0;
    for (var j = i - n + 1; j <= i; j++) {
      sq += (v[j] - m) * (v[j] - m);
    }
    final sd = sqrt(sq / n);
    up[i] = m + k * sd;
    lo[i] = m - k * sd;
  }
  return Bands(up, mid, lo);
}

// ───────────── دعم ومقاومة ─────────────

class Levels {
  const Levels(this.support, this.resistance);
  final List<double> support, resistance;
}

/// قمم وقيعان محلية (Swing points) والأقرب للسعر الحالي أولاً.
Levels pivotLevels(List<Candle> c, {int window = 5, int max = 3}) {
  if (c.length < window * 2 + 1) return const Levels([], []);
  final last = c.last.close;
  final lows = <double>[], highs = <double>[];
  for (var i = window; i < c.length - window; i++) {
    var isLow = true, isHigh = true;
    for (var j = i - window; j <= i + window; j++) {
      if (c[j].low < c[i].low) isLow = false;
      if (c[j].high > c[i].high) isHigh = false;
    }
    if (isLow) lows.add(c[i].low);
    if (isHigh) highs.add(c[i].high);
  }
  final sup = lows.where((x) => x < last).toList()..sort((a, b) => b.compareTo(a));
  final res = highs.where((x) => x > last).toList()..sort();
  return Levels(_dedupe(sup).take(max).toList(), _dedupe(res).take(max).toList());
}

List<double> _dedupe(List<double> v) {
  final out = <double>[];
  for (final x in v) {
    if (out.isEmpty || (x - out.last).abs() / x > 0.01) out.add(x);
  }
  return out;
}

// ───────────── الإشارات والملخص ─────────────

enum Verdict { buy, sell, neutral }

class Signal {
  const Signal(this.name, this.verdict, this.detail);
  final String name;
  final Verdict verdict;
  final String detail;
}

class TechnicalSummary {
  const TechnicalSummary(this.signals);
  final List<Signal> signals;

  int get buy => signals.where((s) => s.verdict == Verdict.buy).length;
  int get sell => signals.where((s) => s.verdict == Verdict.sell).length;
  int get neutral => signals.length - buy - sell;

  String get overall {
    if (signals.isEmpty) return 'بيانات غير كافية';
    final score = buy - sell;
    if (score >= 3) return 'إيجابي بقوة';
    if (score >= 1) return 'إيجابي';
    if (score <= -3) return 'سلبي بقوة';
    if (score <= -1) return 'سلبي';
    return 'محايد';
  }
}

TechnicalSummary analyzeTechnical(List<Candle> c) {
  final signals = <Signal>[];
  if (c.length < 30) return TechnicalSummary(signals);
  final closes = [for (final x in c) x.close];
  final last = closes.last;

  final r = rsi(closes).last;
  if (r != null) {
    if (r < 30) {
      signals.add(Signal('RSI', Verdict.buy, 'تشبّع بيعي (${r.toStringAsFixed(1)})'));
    } else if (r > 70) {
      signals.add(Signal('RSI', Verdict.sell, 'تشبّع شرائي (${r.toStringAsFixed(1)})'));
    } else {
      signals.add(Signal('RSI', Verdict.neutral, 'منطقة متوازنة (${r.toStringAsFixed(1)})'));
    }
  }

  final m = macd(closes);
  final ml = m.line.last, ms = m.signal.last;
  if (ml != null && ms != null) {
    signals.add(ml > ms
        ? const Signal('MACD', Verdict.buy, 'الخط أعلى من خط الإشارة')
        : const Signal('MACD', Verdict.sell, 'الخط أدنى من خط الإشارة'));
  }

  for (final n in [20, 50, 200]) {
    final s = sma(closes, n).last;
    if (s == null) continue;
    signals.add(last > s
        ? Signal('SMA$n', Verdict.buy, 'السعر أعلى من المتوسط (${s.toStringAsFixed(2)})')
        : Signal('SMA$n', Verdict.sell, 'السعر أدنى من المتوسط (${s.toStringAsFixed(2)})'));
  }

  final s50 = sma(closes, 50).last, s200 = sma(closes, 200).last;
  if (s50 != null && s200 != null) {
    signals.add(s50 > s200
        ? const Signal('تقاطع 50/200', Verdict.buy, 'المتوسط 50 أعلى من 200 (Golden)')
        : const Signal('تقاطع 50/200', Verdict.sell, 'المتوسط 50 أدنى من 200 (Death)'));
  }

  final b = bollinger(closes);
  final up = b.upper.last, lo = b.lower.last;
  if (up != null && lo != null) {
    if (last < lo) {
      signals.add(const Signal('بولينجر', Verdict.buy, 'السعر تحت النطاق السفلي'));
    } else if (last > up) {
      signals.add(const Signal('بولينجر', Verdict.sell, 'السعر فوق النطاق العلوي'));
    } else {
      signals.add(const Signal('بولينجر', Verdict.neutral, 'السعر داخل النطاق'));
    }
  }
  return TechnicalSummary(signals);
}
