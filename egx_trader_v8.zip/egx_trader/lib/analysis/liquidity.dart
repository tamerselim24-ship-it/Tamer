import '../models.dart';
import 'technical.dart';

/// On-Balance Volume.
List<double> obv(List<Candle> c) {
  final out = <double>[];
  var acc = 0.0;
  for (var i = 0; i < c.length; i++) {
    if (i > 0) {
      if (c[i].close > c[i - 1].close) {
        acc += c[i].volume;
      } else if (c[i].close < c[i - 1].close) {
        acc -= c[i].volume;
      }
    }
    out.add(acc);
  }
  return out;
}

/// Money Flow Index.
List<double?> mfi(List<Candle> c, [int n = 14]) {
  final out = List<double?>.filled(c.length, null);
  if (c.length <= n) return out;
  final tp = [for (final x in c) (x.high + x.low + x.close) / 3];
  final pos = List<double>.filled(c.length, 0);
  final neg = List<double>.filled(c.length, 0);
  for (var i = 1; i < c.length; i++) {
    final flow = tp[i] * c[i].volume;
    if (tp[i] > tp[i - 1]) {
      pos[i] = flow;
    } else if (tp[i] < tp[i - 1]) {
      neg[i] = flow;
    }
  }
  for (var i = n; i < c.length; i++) {
    var p = 0.0, q = 0.0;
    for (var j = i - n + 1; j <= i; j++) {
      p += pos[j];
      q += neg[j];
    }
    out[i] = q == 0 ? 100 : 100 - 100 / (1 + p / q);
  }
  return out;
}

class LiquidityStats {
  const LiquidityStats({
    required this.avgVolume20,
    required this.avgValue20,
    required this.volumeRatio,
    required this.obvRising,
    required this.mfi,
  });

  final double avgVolume20;
  final double avgValue20;

  /// حجم آخر يوم ÷ متوسط 20 يوم.
  final double volumeRatio;
  final bool obvRising;
  final double? mfi;

  String get activity {
    if (volumeRatio >= 2) return 'نشاط استثنائي';
    if (volumeRatio >= 1.3) return 'نشاط أعلى من المعتاد';
    if (volumeRatio >= 0.7) return 'نشاط طبيعي';
    return 'نشاط ضعيف';
  }
}

LiquidityStats? analyzeLiquidity(List<Candle> c) {
  if (c.length < 21) return null;
  final recent = c.sublist(c.length - 21, c.length - 1); // آخر 20 يوم قبل اليوم
  final avgVol = recent.fold<double>(0, (a, x) => a + x.volume) / recent.length;
  final avgVal =
      recent.fold<double>(0, (a, x) => a + x.volume * x.close) / recent.length;
  final o = obv(c);
  final obvSma = sma(o, 20).last;
  return LiquidityStats(
    avgVolume20: avgVol,
    avgValue20: avgVal,
    volumeRatio: avgVol == 0 ? 0 : c.last.volume / avgVol,
    obvRising: obvSma != null && o.last > obvSma,
    mfi: mfi(c).last,
  );
}
