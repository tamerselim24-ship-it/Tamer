class Candle {
  const Candle({
    required this.date,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  final DateTime date;
  final double open, high, low, close;
  final double volume;
}

class Quote {
  const Quote({
    required this.symbol,
    required this.name,
    required this.sector,
    required this.last,
    required this.prevClose,
    required this.open,
    required this.high,
    required this.low,
    required this.volume,
    required this.value,
    this.asOf,
  });

  final String symbol;
  final String name;
  final String sector;
  final double last, prevClose, open, high, low;

  /// عدد الأسهم المتداولة.
  final double volume;

  /// قيمة التداول بالجنيه.
  final double value;

  /// تاريخ آخر جلسة تداول للبيانات دي (لو معروف).
  final DateTime? asOf;

  double get change => last - prevClose;
  double get changePct => prevClose == 0 ? 0 : change / prevClose * 100;
}

/// بيانات مالية أساسية (آخر 12 شهر). أي حقل ممكن يكون null لو مش متاح.
class Fundamentals {
  const Fundamentals({
    this.eps,
    this.bookValuePerShare,
    this.dividendPerShare,
    this.revenue,
    this.netProfit,
    this.totalEquity,
    this.totalDebt,
    this.sharesOutstanding,
    this.revenueGrowthPct,
  });

  final double? eps;
  final double? bookValuePerShare;
  final double? dividendPerShare;
  final double? revenue;
  final double? netProfit;
  final double? totalEquity;
  final double? totalDebt;
  final double? sharesOutstanding;
  final double? revenueGrowthPct;
}
