import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class LineSeries {
  const LineSeries(this.data, this.color, {this.width = 1.5, this.dashed = false});
  final List<double?> data;
  final Color color;
  final double width;
  final bool dashed;
}

/// رسم خطي لعدة سلاسل (سعر + متوسطات + بولينجر، أو RSI…).
class MultiLineChart extends StatelessWidget {
  const MultiLineChart({
    super.key,
    required this.series,
    this.count = 120,
    this.height = 220,
    this.minY,
    this.maxY,
    this.guides = const [],
  });

  final List<LineSeries> series;
  final int count;
  final double height;
  final double? minY, maxY;
  final List<double> guides;

  @override
  Widget build(BuildContext context) {
    final n = series.first.data.length;
    final from = max(0, n - count);
    var lo = double.infinity, hi = -double.infinity;
    final bars = <LineChartBarData>[];
    for (final s in series) {
      final spots = <FlSpot>[];
      for (var i = from; i < n; i++) {
        final v = s.data[i];
        if (v == null) continue;
        spots.add(FlSpot((i - from).toDouble(), v));
        lo = min(lo, v);
        hi = max(hi, v);
      }
      bars.add(LineChartBarData(
        spots: spots,
        isCurved: false,
        dotData: const FlDotData(show: false),
        barWidth: s.width,
        color: s.color,
        dashArray: s.dashed ? [4, 4] : null,
      ));
    }
    if (lo == double.infinity) return SizedBox(height: height);
    final pad = (hi - lo) * 0.05;
    final yMin = minY ?? lo - pad;
    final yMax = maxY ?? hi + pad;

    return SizedBox(
      height: height,
      child: LineChart(LineChartData(
        minY: yMin,
        maxY: yMax,
        lineBarsData: bars,
        gridData: const FlGridData(show: true, drawVerticalLine: false),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 44,
              getTitlesWidget: (v, meta) => Text(
                v.toStringAsFixed(v.abs() >= 100 ? 0 : 1),
                style: const TextStyle(fontSize: 10),
              ),
            ),
          ),
        ),
        extraLinesData: ExtraLinesData(horizontalLines: [
          for (final g in guides)
            HorizontalLine(y: g, color: Colors.grey, strokeWidth: 1, dashArray: [5, 5]),
        ]),
      )),
    );
  }
}

/// أعمدة صغيرة (حجم التداول، MACD histogram…).
class MiniBars extends StatelessWidget {
  const MiniBars({
    super.key,
    required this.values,
    required this.colors,
    this.count = 120,
    this.height = 100,
  });

  final List<double?> values;
  final List<Color> colors;
  final int count;
  final double height;

  @override
  Widget build(BuildContext context) {
    final n = values.length;
    final from = max(0, n - count);
    final groups = <BarChartGroupData>[
      for (var i = from; i < n; i++)
        if (values[i] != null)
          BarChartGroupData(x: i - from, barRods: [
            BarChartRodData(
              toY: values[i]!,
              width: 2,
              color: colors[i],
              borderRadius: BorderRadius.zero,
            ),
          ]),
    ];
    return SizedBox(
      height: height,
      child: BarChart(BarChartData(
        barGroups: groups,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: const FlTitlesData(show: false),
        barTouchData: BarTouchData(enabled: false),
      )),
    );
  }
}

class LegendDot extends StatelessWidget {
  const LegendDot(this.color, this.label, {super.key});
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 10, height: 10, color: color),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 11)),
        const SizedBox(width: 10),
      ]);
}
