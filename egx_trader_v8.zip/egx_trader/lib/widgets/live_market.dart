import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// جدول السوق المصري من TradingView (Screener widget الرسمي) داخل WebView.
/// للقراءة بس، مش داخل في التحليلات. ما اتجرّبش: مش مؤكد إن الويدجت بيدعم
/// market = egypt، ولا حجم التأخير في بيانات EGX.
class LiveMarketView extends StatefulWidget {
  const LiveMarketView({super.key});

  @override
  State<LiveMarketView> createState() => _LiveMarketViewState();
}

class _LiveMarketViewState extends State<LiveMarketView> {
  late final WebViewController _controller;

  static const _html = '''
<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>html,body{margin:0;padding:0;height:100%;background:#131722;}</style></head>
<body>
<div class="tradingview-widget-container" style="height:100%;width:100%">
  <div class="tradingview-widget-container__widget" style="height:calc(100% - 24px);width:100%"></div>
  <div class="tradingview-widget-copyright" style="font-size:11px;text-align:center;height:24px;line-height:24px"><a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank" style="color:#2962ff;text-decoration:none">Track all markets on TradingView</a></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-screener.js" async>
  {"width": "100%", "height": "100%", "defaultColumn": "overview", "defaultScreen": "most_capitalized", "market": "egypt", "showToolbar": true, "colorTheme": "dark", "locale": "ar_AE", "isTransparent": false}
  </script>
</div></body></html>
''';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF131722))
      ..loadHtmlString(_html, baseUrl: 'https://www.tradingview.com');
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(child: WebViewWidget(controller: _controller)),
      const Padding(
        padding: EdgeInsets.all(8),
        child: SelectableText(
          'لو الجدول ما ظهرش، افتح الرابط ده في المتصفح:\n'
          'https://www.tradingview.com/markets/stocks-egypt/',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 11, color: Colors.grey),
        ),
      ),
    ]);
  }
}
