import '../models.dart';
import 'mock_source.dart';
import 'scraper_source.dart';
import 'yahoo_source.dart';

/// ─────────────────────────────────────────────────────────────
/// ضع هنا رابط الصفحة العامة اللي فيها جدول أسعار الأسهم.
/// لو سيبته فاضي التطبيق يستخدم ياهو فاينانس.
/// راجع شروط استخدام الموقع قبل السحب منه.
/// ─────────────────────────────────────────────────────────────
const String kQuotesUrl = '';

abstract class MarketDataSource {
  Future<List<Quote>> fetchQuotes();
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260});
  Future<Fundamentals?> fetchFundamentals(String symbol);

  /// يدوّر على سهم برمزه (لإضافة أسهم جديدة). null = السهم غير موجود.
  Future<Quote?> lookup(String symbol);

  /// true لو البيانات المعروضة تجريبية.
  bool get isDemo;

  /// سبب آخر فشل في المصدر الأساسي (لو فيه).
  String? get lastError;
}

/// يجرب المصدر الأساسي لقايمة الأسعار. لو فشل بيرجع للبيانات التجريبية
/// ويعلّم إن البيانات تجريبية، وساعتها السجل والبيانات المالية كمان تجريبيين
/// (علشان الشاشات تفضل متسقة). لو الأسعار حقيقية وفشل جلب سجل أو بيانات
/// مالية لسهم، الخطأ بيظهر كما هو ومش بنعرض أرقام مزيّفة مكانه.
class FallbackSource implements MarketDataSource {
  FallbackSource(this.primary, this.fallback);

  final MarketDataSource primary;
  final MarketDataSource fallback;
  bool _demo = false;
  String? _lastError;

  @override
  bool get isDemo => _demo;

  @override
  String? get lastError => _lastError;

  MarketDataSource get _active => _demo ? fallback : primary;

  @override
  Future<List<Quote>> fetchQuotes() async {
    try {
      final q = await primary.fetchQuotes();
      _demo = false;
      _lastError = null;
      return q;
    } catch (e) {
      _demo = true;
      _lastError = e.toString();
      return fallback.fetchQuotes();
    }
  }

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) =>
      _active.fetchHistory(symbol, days: days);

  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) =>
      _active.fetchFundamentals(symbol);

  @override
  Future<Quote?> lookup(String symbol) => _active.lookup(symbol);
}

/// الافتراضي: ياهو، ولو فشل يرجع للبيانات التجريبية.
/// لو حطيت رابط في [kQuotesUrl] بيستخدم السحب من الجدول بدل ياهو.
MarketDataSource createDataSource() {
  final MarketDataSource primary =
      kQuotesUrl.isEmpty ? YahooDataSource() : ScrapedDataSource(Uri.parse(kQuotesUrl));
  return FallbackSource(primary, MockDataSource());
}
