import 'package:egx_trader/analysis/technical.dart';
import 'package:egx_trader/util.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('SMA', () {
    final r = sma([1, 2, 3, 4, 5], 3);
    expect(r[1], isNull);
    expect(r[2], 2);
    expect(r[4], 4);
  });

  test('EMA يبدأ بمتوسط بسيط', () {
    final r = ema([1, 2, 3, 4, 5], 3);
    expect(r[2], 2);
    expect(r[3], closeTo(3, 1e-9)); // 4*0.5 + 2*0.5
  });

  test('RSI = 100 لما السعر بيطلع فقط', () {
    final up = [for (var i = 0; i < 30; i++) 10.0 + i];
    expect(rsi(up).last, 100);
  });

  test('RSI قريب من 0 لما السعر بينزل فقط', () {
    final down = [for (var i = 0; i < 30; i++) 100.0 - i];
    expect(rsi(down).last, closeTo(0, 1e-9));
  });

  test('بولينجر: النطاق حوالين المتوسط', () {
    final v = [for (var i = 0; i < 40; i++) 10.0 + (i % 2)];
    final b = bollinger(v);
    expect(b.upper.last! > b.mid.last!, isTrue);
    expect(b.lower.last! < b.mid.last!, isTrue);
  });

  test('parseNum يفهم الأرقام العربية والفواصل', () {
    expect(parseNum('١٢٣٫٥'), 123.5);
    expect(parseNum('1,234.50'), 1234.5);
    expect(parseNum('2.5M'), 2500000);
    expect(parseNum('-'), isNull);
  });
}
