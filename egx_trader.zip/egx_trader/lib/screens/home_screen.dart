import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../util.dart';
import 'liquidity_screen.dart';
import 'stock_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.state});
  final AppState state;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  String _query = '';

  static const _titles = ['الأسهم', 'قائمة المراقبة', 'السيولة'];

  void _open(Quote q) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => StockScreen(quote: q, source: widget.state.source),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.state,
      builder: (context, _) {
        final s = widget.state;
        return Scaffold(
          appBar: AppBar(
            title: Text(_titles[_tab]),
            actions: [
              IconButton(
                icon: s.loading
                    ? const SizedBox(
                        width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.refresh),
                onPressed: s.loading ? null : s.refresh,
              ),
            ],
          ),
          body: Column(children: [
            if (s.isDemo)
              Container(
                width: double.infinity,
                color: Colors.amber.shade900,
                padding: const EdgeInsets.all(6),
                child: const Text(
                  'بعض البيانات المعروضة تجريبية (فشل جلبها من المصدر)',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12),
                ),
              ),
            if (s.error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(s.error!, style: const TextStyle(color: Colors.redAccent)),
              ),
            Expanded(child: _body(s)),
          ]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.show_chart), label: 'الأسهم'),
              NavigationDestination(icon: Icon(Icons.star), label: 'المراقبة'),
              NavigationDestination(icon: Icon(Icons.water_drop), label: 'السيولة'),
            ],
          ),
        );
      },
    );
  }

  Widget _body(AppState s) {
    if (s.quotes.isEmpty) {
      return Center(child: s.loading ? const CircularProgressIndicator() : const Text('لا توجد بيانات'));
    }
    switch (_tab) {
      case 1:
        final list = s.quotes.where((q) => s.watchlist.contains(q.symbol)).toList();
        if (list.isEmpty) {
          return const Center(child: Text('ضيف أسهم بالضغط على النجمة'));
        }
        return _list(s, list);
      case 2:
        return LiquidityView(quotes: s.quotes, onTap: _open);
      default:
        final q = _query.trim().toLowerCase();
        final list = q.isEmpty
            ? s.quotes
            : s.quotes
                .where((x) => x.symbol.toLowerCase().contains(q) || x.name.contains(q))
                .toList();
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'ابحث بالرمز أو الاسم',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(child: _list(s, list)),
        ]);
    }
  }

  Widget _list(AppState s, List<Quote> list) {
    return RefreshIndicator(
      onRefresh: s.refresh,
      child: ListView.separated(
        itemCount: list.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final q = list[i];
          final color = changeColor(q.change);
          final watched = s.watchlist.contains(q.symbol);
          return ListTile(
            onTap: () => _open(q),
            leading: IconButton(
              icon: Icon(watched ? Icons.star : Icons.star_border,
                  color: watched ? Colors.amber : null),
              onPressed: () => s.toggleWatch(q.symbol),
            ),
            title: Text(q.symbol, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${q.name} • حجم ${fmtCompact(q.volume)}'),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(fmtNum(q.last), style: const TextStyle(fontSize: 16)),
                Text(fmtPct(q.changePct), style: TextStyle(color: color, fontSize: 12)),
              ],
            ),
          );
        },
      ),
    );
  }
}
