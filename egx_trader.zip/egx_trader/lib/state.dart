import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/data_source.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  AppState(this.source);

  final MarketDataSource source;
  List<Quote> quotes = const [];
  final Set<String> watchlist = {};
  bool loading = false;
  String? error;
  DateTime? updatedAt;

  bool get isDemo => source.isDemo;

  static const _prefsKey = 'watchlist';

  Future<void> init() async {
    try {
      final p = await SharedPreferences.getInstance();
      watchlist.addAll(p.getStringList(_prefsKey) ?? const []);
    } catch (_) {}
    await refresh();
  }

  Future<void> refresh() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      quotes = await source.fetchQuotes();
      updatedAt = DateTime.now();
    } catch (e) {
      error = 'تعذّر تحميل الأسعار: $e';
    }
    loading = false;
    notifyListeners();
  }

  Future<void> toggleWatch(String symbol) async {
    if (!watchlist.remove(symbol)) watchlist.add(symbol);
    notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList(_prefsKey, watchlist.toList());
    } catch (_) {}
  }
}
