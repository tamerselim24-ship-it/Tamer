import 'dart:convert';

import 'package:html/dom.dart';
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;

import '../models.dart';
import '../util.dart';
import 'data_source.dart';

/// سحب عام من جدول HTML: بيدوّر على أول <table> ويربط الأعمدة بالأسماء
/// (عربي أو إنجليزي) من عناوين الأعمدة.
///
/// ملاحظة: ده ما اتجرّبش على موقع بعينه. كل موقع ليه هيكل مختلف، فغالبًا
/// هتحتاج تعدّل كلمات البحث في [_headers] أو الـ selector حسب الموقع اللي تختاره.
/// السجل التاريخي والبيانات المالية مش متاحين من الجدول ده، فبيرموا خطأ
/// والـ FallbackSource بيعوّضهم ببيانات تجريبية (والتطبيق بيعرض تنبيه بده).
class ScrapedDataSource implements MarketDataSource {
  ScrapedDataSource(this.quotesUrl, {http.Client? client})
      : _client = client ?? http.Client();

  final Uri quotesUrl;
  final http.Client _client;

  @override
  bool get isDemo => false;

  static const _headers = <String, List<String>>{
    'symbol': ['الرمز', 'الكود', 'symbol', 'code', 'ticker'],
    'name': ['الاسم', 'الشركة', 'name', 'company'],
    'last': ['آخر', 'الإغلاق', 'الاغلاق', 'السعر', 'last', 'close', 'price'],
    'prev': ['السابق', 'prev'],
    'open': ['الافتتاح', 'فتح', 'open'],
    'high': ['أعلى', 'اعلى', 'high'],
    'low': ['أدنى', 'ادنى', 'low'],
    'volume': ['الكمية', 'الحجم', 'volume', 'vol'],
    'value': ['القيمة', 'value', 'turnover'],
    'pct': ['%', 'نسبة', 'change %', 'chg%'],
  };

  @override
  Future<List<Quote>> fetchQuotes() async {
    final res = await _client.get(quotesUrl, headers: {
      'User-Agent': 'EGXTraderApp/0.1',
      'Accept-Language': 'ar,en;q=0.8',
    }).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');

    final doc = html.parse(utf8.decode(res.bodyBytes, allowMalformed: true));
    final table = doc.querySelector('table');
    if (table == null) throw Exception('لا يوجد جدول في الصفحة');

    final heads = table
        .querySelectorAll('th')
        .map((e) => e.text.trim().toLowerCase())
        .toList();
    final idx = <String, int>{};
    for (final entry in _headers.entries) {
      final i = heads.indexWhere((h) => entry.value.any((k) => h.contains(k.toLowerCase())));
      if (i >= 0) idx[entry.key] = i;
    }
    if (!idx.containsKey('symbol') || !idx.containsKey('last')) {
      throw Exception('تعذّر ربط أعمدة الرمز والسعر');
    }

    String? cell(List<Element> tds, String key) {
      final i = idx[key];
      return (i == null || i >= tds.length) ? null : tds[i].text.trim();
    }

    final quotes = <Quote>[];
    for (final tr in table.querySelectorAll('tr')) {
      final tds = tr.querySelectorAll('td');
      if (tds.isEmpty) continue;
      final symbol = cell(tds, 'symbol');
      final last = parseNum(cell(tds, 'last'));
      if (symbol == null || symbol.isEmpty || last == null) continue;

      var prev = parseNum(cell(tds, 'prev'));
      final pct = parseNum(cell(tds, 'pct'));
      prev ??= pct != null && pct != -100 ? last / (1 + pct / 100) : last;
      final volume = parseNum(cell(tds, 'volume')) ?? 0;

      quotes.add(Quote(
        symbol: symbol,
        name: cell(tds, 'name') ?? symbol,
        sector: '',
        last: last,
        prevClose: prev,
        open: parseNum(cell(tds, 'open')) ?? last,
        high: parseNum(cell(tds, 'high')) ?? last,
        low: parseNum(cell(tds, 'low')) ?? last,
        volume: volume,
        value: parseNum(cell(tds, 'value')) ?? volume * last,
      ));
    }
    if (quotes.isEmpty) throw Exception('لم يتم العثور على أسهم');
    return quotes;
  }

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) =>
      Future.error(UnimplementedError('السجل التاريخي غير متاح من هذا المصدر'));

  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) =>
      Future.error(UnimplementedError('البيانات المالية غير متاحة من هذا المصدر'));
}
