import '../models.dart';
import 'mock_source.dart';
import 'scraper_source.dart';
import 'yahoo_source.dart';

/// ─────────────────────────────────────────────────────────────
/// ضع هنا رابط الصفحة العامة اللي فيها جدول أسعار الأسهم.
/// لو سيبته فاضي التطبيق يشتغل ببيانات تجريبية بالكامل.
/// راجع شروط استخدام الموقع قبل السحب منه.
/// ─────────────────────────────────────────────────────────────
const String kQuotesUrl = '';

abstract class MarketDataSource {
  Future<List<Quote>> fetchQuotes();
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260});
  Future<Fundamentals?> fetchFundamentals(String symbol);

  /// true لو أي جزء من البيانات المعروضة تجريبي.
  bool get isDemo;
}

/// يجرب المصدر الأساسي، ولو فشل يرجع للبيانات التجريبية (ويعلّم إن البيانات تجريبية).
class FallbackSource implements MarketDataSource {
  FallbackSource(this.primary, this.fallback);

  final MarketDataSource primary;
  final MarketDataSource fallback;
  bool _usedFallback = false;

  @override
  bool get isDemo => _usedFallback;

  Future<T> _try<T>(Future<T> Function(MarketDataSource s) call) async {
    try {
      return await call(primary);
    } catch (_) {
      _usedFallback = true;
      return call(fallback);
    }
  }

  @override
  Future<List<Quote>> fetchQuotes() => _try((s) => s.fetchQuotes());

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) =>
      _try((s) => s.fetchHistory(symbol, days: days));

  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) =>
      _try((s) => s.fetchFundamentals(symbol));
}

/// الافتراضي: ياهو، ولو فشل يرجع للبيانات التجريبية.
/// لو حطيت رابط في [kQuotesUrl] بيستخدم السحب من الجدول بدل ياهو.
MarketDataSource createDataSource() {
  final MarketDataSource primary =
      kQuotesUrl.isEmpty ? YahooDataSource() : ScrapedDataSource(Uri.parse(kQuotesUrl));
  return FallbackSource(primary, MockDataSource());
}
