import 'dart:math';

import '../models.dart';
import 'data_source.dart';

class _Co {
  const _Co(this.symbol, this.name, this.sector, this.base, this.pe, this.pb, this.dy, this.shares);
  final String symbol, name, sector;
  final double base, pe, pb, dy, shares;
}

/// بيانات تجريبية مولّدة عشوائيًا (ثابتة لكل رمز). الأسعار تقريبية للتجربة فقط
/// وليست أسعار السوق الفعلية ولا يُعتمد عليها في أي قرار.
const _companies = <_Co>[
  _Co('COMI', 'البنك التجاري الدولي', 'بنوك', 90, 6.5, 1.8, 3.0, 3.0e9),
  _Co('HRHO', 'هيرميس القابضة', 'خدمات مالية', 22, 5.0, 1.0, 5.0, 1.2e9),
  _Co('TMGH', 'مجموعة طلعت مصطفى', 'عقارات', 70, 14.0, 1.4, 1.0, 2.0e9),
  _Co('EAST', 'الشرقية - إيسترن كومباني', 'تبغ', 28, 7.0, 2.2, 8.0, 2.2e9),
  _Co('SWDY', 'السويدي إليكتريك', 'صناعة', 60, 8.0, 2.0, 3.0, 2.1e9),
  _Co('ORWE', 'النساجون الشرقيون', 'منسوجات', 25, 10.0, 1.5, 2.0, 0.6e9),
  _Co('ABUK', 'أبوقير للأسمدة', 'كيماويات', 55, 6.0, 2.5, 7.0, 1.3e9),
  _Co('MFPC', 'مصر لإنتاج الأسمدة - موبكو', 'كيماويات', 40, 5.5, 3.0, 9.0, 0.6e9),
  _Co('ETEL', 'المصرية للاتصالات', 'اتصالات', 38, 9.0, 1.2, 4.0, 1.7e9),
  _Co('EFIH', 'إي فاينانس', 'تكنولوجيا', 18, 18.0, 4.5, 1.5, 1.8e9),
  _Co('FWRY', 'فوري', 'تكنولوجيا', 15, 22.0, 5.0, 0.0, 1.7e9),
  _Co('PHDC', 'بالم هيلز للتعمير', 'عقارات', 7, 12.0, 0.9, 0.0, 2.8e9),
  _Co('ESRS', 'حديد عز', 'صناعة', 65, 9.0, 1.1, 0.0, 0.5e9),
  _Co('EKHO', 'القلعة القابضة', 'استثمار', 3, 25.0, 0.8, 0.0, 1.0e9),
  _Co('ORAS', 'أوراسكوم للإنشاء', 'إنشاءات', 220, 10.0, 1.6, 6.0, 0.1e9),
];

class MockDataSource implements MarketDataSource {
  final Map<String, List<Candle>> _cache = {};

  @override
  bool get isDemo => true;

  int _seed(String s) => s.codeUnits.fold<int>(7, (a, c) => (a * 31 + c) & 0x7fffffff);

  List<Candle> _candles(_Co co, int days) {
    return _cache.putIfAbsent(co.symbol, () {
      final rnd = Random(_seed(co.symbol));
      double gauss() {
        final u = 1 - rnd.nextDouble(), v = rnd.nextDouble();
        return sqrt(-2 * log(u)) * cos(2 * pi * v);
      }

      // نبني تواريخ أيام التداول (الأحد–الخميس) رجوعًا من اليوم.
      final dates = <DateTime>[];
      var d = DateTime.now();
      while (dates.length < 300) {
        if (d.weekday != DateTime.friday && d.weekday != DateTime.saturday) {
          dates.add(DateTime(d.year, d.month, d.day));
        }
        d = d.subtract(const Duration(days: 1));
      }
      final ordered = dates.reversed.toList();

      final baseVol = 2e6 + rnd.nextDouble() * 8e6;
      var price = co.base * (0.85 + rnd.nextDouble() * 0.2);
      final out = <Candle>[];
      for (final date in ordered) {
        final ret = 0.0004 + gauss() * 0.017;
        final open = price * (1 + gauss() * 0.004);
        final close = price * (1 + ret);
        final high = max(open, close) * (1 + rnd.nextDouble() * 0.01);
        final low = min(open, close) * (1 - rnd.nextDouble() * 0.01);
        final vol = baseVol * (0.6 + rnd.nextDouble() * 0.8) * (1 + ret.abs() * 25);
        out.add(Candle(date: date, open: open, high: high, low: low, close: close, volume: vol));
        price = close;
      }
      return out;
    }).takeLast(days);
  }

  _Co _co(String symbol) => _companies.firstWhere((c) => c.symbol == symbol);

  @override
  Future<List<Quote>> fetchQuotes() async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    return [
      for (final co in _companies)
        () {
          final c = _candles(co, 2);
          final last = c.last, prev = c.first;
          return Quote(
            symbol: co.symbol,
            name: co.name,
            sector: co.sector,
            last: last.close,
            prevClose: prev.close,
            open: last.open,
            high: last.high,
            low: last.low,
            volume: last.volume,
            value: last.volume * last.close,
          );
        }(),
    ];
  }

  @override
  Future<Quote?> lookup(String symbol) async {
    for (final q in await fetchQuotes()) {
      if (q.symbol == symbol) return q;
    }
    return null;
  }

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    return _candles(_co(symbol), days);
  }

  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) async {
    final co = _co(symbol);
    final price = _candles(co, 1).last.close;
    final eps = price / co.pe;
    final netProfit = eps * co.shares;
    final equity = price / co.pb * co.shares;
    final rnd = Random(_seed(symbol) + 1);
    return Fundamentals(
      eps: eps,
      bookValuePerShare: price / co.pb,
      dividendPerShare: price * co.dy / 100,
      revenue: netProfit / (0.08 + rnd.nextDouble() * 0.2),
      netProfit: netProfit,
      totalEquity: equity,
      totalDebt: equity * (0.2 + rnd.nextDouble() * 1.5),
      sharesOutstanding: co.shares,
      revenueGrowthPct: -3 + rnd.nextDouble() * 30,
    );
  }
}

extension _TakeLast<T> on List<T> {
  List<T> takeLast(int n) => length <= n ? this : sublist(length - n);
}
