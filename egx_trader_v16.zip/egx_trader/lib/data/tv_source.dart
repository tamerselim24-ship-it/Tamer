import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models.dart';
import 'data_source.dart';
import 'egx_universe.dart';
import 'yahoo_source.dart';

/// أسعار السوق من سكانر TradingView (حوالي 15 دقيقة تأخير) في طلب واحد لكل الأسهم.
/// التاريخ والبيانات المالية بتفضل من ياهو.
///
/// تنبيه: ده endpoint غير رسمي من TradingView، ممكن يتغيّر أو يتحجب في أي وقت،
/// وشروط الموقع ما بتسمحش بالسحب الآلي. للاستخدام الشخصي، ولو فشل بنرجع لياهو.
class TradingViewDataSource implements MarketDataSource {
  TradingViewDataSource(this.yahoo, {http.Client? client})
      : _client = client ?? http.Client();

  final YahooDataSource yahoo;
  final http.Client _client;
  String _label = 'TradingView';

  static final _uri = Uri.parse('https://scanner.tradingview.com/egypt/scan');
  static const _columns = [
    'name',
    'description',
    'close',
    'open',
    'high',
    'low',
    'volume',
    'change_abs',
    'Value.Traded',
    'average_volume_30d_calc',
  ];

  @override
  bool get isDemo => false;

  @override
  String? get lastError => null;

  @override
  String get sourceLabel => _label;

  /// تاريخ جلسة التداول الحالية أو آخر جلسة (الأحد–الخميس، بداية 10 الصبح).
  DateTime _sessionDate() {
    final now = DateTime.now();
    var d = DateTime(now.year, now.month, now.day);
    if (now.hour < 10) d = DateTime(d.year, d.month, d.day - 1);
    while (d.weekday == DateTime.friday || d.weekday == DateTime.saturday) {
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return d;
  }

  double? _n(Object? v) => v is num && v.isFinite ? v.toDouble() : null;

  Quote? _row(Map row) {
    final s = '${row['s'] ?? ''}';
    final d = row['d'];
    if (!s.startsWith('EGX:') || d is! List || d.length < _columns.length) return null;
    final sym = s.substring(4);
    final close = _n(d[2]);
    if (close == null || close <= 0) return null;
    final chg = _n(d[7]) ?? 0;
    final vol = _n(d[6]) ?? 0;
    final desc = '${d[1] ?? sym}';
    return Quote(
      symbol: sym,
      name: kEgxIndex[sym]?.name ?? desc,
      sector: sectorOf(sym),
      last: close,
      prevClose: close - chg,
      open: _n(d[3]) ?? close,
      high: _n(d[4]) ?? close,
      low: _n(d[5]) ?? close,
      volume: vol,
      value: _n(d[8]) ?? vol * close,
      asOf: _sessionDate(),
      avgVolume: _n(d[9]),
    );
  }

  Future<List<Quote>> _scan(List<String>? tickers) async {
    final body = {
      'filter': const [],
      'options': {'lang': 'en'},
      'markets': const ['egypt'],
      'symbols': {
        'query': {'types': const []},
        'tickers': tickers ?? const [],
      },
      'columns': _columns,
      'sort': {'sortBy': 'Value.Traded', 'sortOrder': 'desc'},
      'range': [0, 700],
    };
    final res = await _client
        .post(_uri,
            headers: const {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',
            },
            body: jsonEncode(body))
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw Exception('TradingView HTTP ${res.statusCode}');
    final json = jsonDecode(utf8.decode(res.bodyBytes));
    final data = json is Map ? json['data'] : null;
    if (data is! List) throw Exception('رد غير متوقع من TradingView');
    return data.whereType<Map>().map(_row).whereType<Quote>().toList();
  }

  @override
  Future<List<Quote>> fetchQuotes({QuotesProgress? onProgress}) async {
    try {
      final q = await _scan(null);
      if (q.length < 20) throw Exception('عدد أسهم قليل (${q.length})');
      _label = 'TradingView (متأخر حوالي 15 دقيقة)';
      onProgress?.call(q, q.length, q.length);
      return q;
    } catch (e) {
      _label = 'ياهو (TradingView فشل: ${e.toString().split("\n").first})';
      return yahoo.fetchQuotes(onProgress: onProgress);
    }
  }

  @override
  Future<Quote?> lookup(String symbol) async {
    try {
      final q = await _scan(['EGX:$symbol']);
      if (q.isNotEmpty) return q.first;
    } catch (_) {}
    return yahoo.lookup(symbol);
  }

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) =>
      yahoo.fetchHistory(symbol, days: days);

  /// ياهو الأول. لو معندوش بيانات (أو فشل) بنجرّب سكانر TradingView.
  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) async {
    try {
      final y = await yahoo.fetchFundamentals(symbol);
      if (y != null) return y;
    } catch (_) {}
    try {
      return await _tvFundamentals(symbol);
    } catch (_) {
      return null;
    }
  }

  // أسماء الحقول غير مؤكدة. لو TradingView رفض واحد منها بنجرّب قايمة أقصر.
  static const _fundTiers = <List<String>>[
    [
      'close', 'earnings_per_share_basic_ttm', 'book_value_per_share_fq',
      'dividends_yield', 'total_revenue', 'net_income', 'total_debt',
      'total_shares_outstanding_fundamental', 'return_on_equity',
      'debt_to_equity', 'total_revenue_yoy_growth_ttm',
    ],
    [
      'close', 'earnings_per_share_basic_ttm', 'book_value_per_share_fq',
      'dividends_yield', 'return_on_equity', 'debt_to_equity',
    ],
    ['close', 'earnings_per_share_basic_ttm', 'dividends_yield'],
  ];

  Future<Fundamentals?> _tvFundamentals(String symbol) async {
    for (final cols in _fundTiers) {
      final res = await _client
          .post(_uri,
              headers: const {'Content-Type': 'application/json'},
              body: jsonEncode({
                'filter': const [],
                'options': {'lang': 'en'},
                'markets': const ['egypt'],
                'symbols': {
                  'query': {'types': const []},
                  'tickers': ['EGX:$symbol'],
                },
                'columns': cols,
                'range': [0, 1],
              }))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode == 400) continue; // حقل غير معروف، نجرّب قايمة أقصر
      if (res.statusCode != 200) return null;
      final json = jsonDecode(utf8.decode(res.bodyBytes));
      final data = json is Map ? json['data'] : null;
      if (data is! List || data.isEmpty) return null;
      final d = (data.first as Map)['d'];
      if (d is! List) return null;
      final v = <String, double?>{
        for (var i = 0; i < cols.length && i < d.length; i++) cols[i]: _n(d[i]),
      };
      final price = v['close'];
      final yld = v['dividends_yield'];
      final bv = v['book_value_per_share_fq'];
      final shares = v['total_shares_outstanding_fundamental'];
      final np = v['net_income'];
      final roe = v['return_on_equity'];
      final debt = v['total_debt'];
      final de = v['debt_to_equity'];
      double? equity;
      if (bv != null && shares != null) {
        equity = bv * shares;
      } else if (np != null && roe != null && roe > 0) {
        equity = np / (roe / 100);
      } else if (debt != null && de != null && de > 0) {
        equity = debt / de;
      }
      final f = Fundamentals(
        eps: v['earnings_per_share_basic_ttm'],
        bookValuePerShare: bv,
        dividendPerShare: (yld != null && yld > 0 && price != null) ? price * yld / 100 : null,
        revenue: v['total_revenue'],
        netProfit: np,
        totalEquity: equity,
        totalDebt: debt,
        sharesOutstanding: shares,
        revenueGrowthPct: v['total_revenue_yoy_growth_ttm'],
      );
      final empty = f.eps == null &&
          f.bookValuePerShare == null &&
          f.revenue == null &&
          f.netProfit == null &&
          f.totalDebt == null &&
          f.dividendPerShare == null;
      return empty ? null : f;
    }
    return null;
  }
}
