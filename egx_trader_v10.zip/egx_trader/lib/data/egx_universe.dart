/// قايمة الأسهم المقيدة في البورصة المصرية (الرمز، الاسم، القطاع).
///
/// الرموز مأخوذة من قايمة عامة للأسهم المقيدة. القطاعات من تصنيفي أنا حسب
/// نشاط الشركة (مش التصنيف الرسمي للبورصة)، فممكن سهم يتصنّف غلط.
/// الأسماء اللي بالإنجليزي مختصرة لأن الاسم العربي مش متأكد منه.
/// مش كل الرموز موجودة على ياهو، واللي مش موجود بيتجاهل تلقائيًا.
class EgxStock {
  const EgxStock(this.symbol, this.name, this.sector);
  final String symbol, name, sector;
}

const _bank = 'البنوك';
const _fin = 'الخدمات المالية والتأمين';
const _re = 'العقارات والإسكان';
const _eng = 'المقاولات والصناعات الهندسية';
const _cem = 'الأسمنت ومواد البناء';
const _met = 'الحديد والمعادن';
const _chem = 'الكيماويات والأسمدة';
const _energy = 'الطاقة والبترول';
const _food = 'الأغذية والمشروبات والزراعة';
const _pharma = 'الأدوية والرعاية الصحية';
const _tex = 'الغزل والنسيج والملابس';
const _tour = 'السياحة والفنادق';
const _tech = 'الاتصالات والتكنولوجيا';
const _trans = 'النقل والخدمات اللوجستية';
const _edu = 'التعليم';
const _misc = 'ورق وتعبئة وصناعات متنوعة';

/// ترتيب عرض القطاعات.
const kSectorOrder = <String>[
  _bank, _fin, _re, _eng, _cem, _met, _chem, _energy, _food, _pharma,
  _tex, _tour, _tech, _trans, _edu, _misc,
];

const kOtherSector = 'أخرى';

const kEgxStocks = <EgxStock>[
  // البنوك
  EgxStock('COMI', 'البنك التجاري الدولي', _bank),
  EgxStock('QNBE', 'بنك قطر الوطني مصر', _bank),
  EgxStock('HDBK', 'بنك التعمير والإسكان', _bank),
  EgxStock('BQDC', 'بنك القاهرة', _bank),
  EgxStock('ADIB', 'مصرف أبوظبي الإسلامي - مصر', _bank),
  EgxStock('CANA', 'بنك قناة السويس', _bank),
  EgxStock('FAIT', 'بنك فيصل الإسلامي', _bank),
  EgxStock('CIEB', 'كريدي أجريكول مصر', _bank),
  EgxStock('EXPA', 'البنك المصري لتنمية الصادرات', _bank),
  EgxStock('UBEE', 'المصرف المتحد', _bank),
  EgxStock('SAUD', 'بنك البركة مصر', _bank),
  EgxStock('EGBE', 'البنك المصري الخليجي', _bank),
  EgxStock('SAIB', 'بنك الشركة المصرفية العربية الدولية', _bank),

  // الخدمات المالية والتأمين
  EgxStock('HRHO', 'هيرميس القابضة', _fin),
  EgxStock('BTFH', 'بلتون القابضة', _fin),
  EgxStock('CCAP', 'القلعة (قلعة للاستثمارات المالية)', _fin),
  EgxStock('RAYA', 'راية القابضة', _fin),
  EgxStock('CICH', 'سي آي كابيتال', _fin),
  EgxStock('VALU', 'فاليو', _fin),
  EgxStock('OIH', 'أوراسكوم للاستثمار القابضة', _fin),
  EgxStock('ACAP', 'إيه كابيتال القابضة', _fin),
  EgxStock('CNFN', 'كونتكت المالية القابضة', _fin),
  EgxStock('OFH', 'أو بي المالية القابضة', _fin),
  EgxStock('ACTF', 'أكت فاينانشال', _fin),
  EgxStock('NAHO', 'نعيم القابضة', _fin),
  EgxStock('ASPI', 'أسباير كابيتال', _fin),
  EgxStock('ODIN', 'أودن للاستثمارات', _fin),
  EgxStock('EBSC', 'أصول للسمسرة', _fin),
  EgxStock('EASB', 'الثمار للسمسرة', _fin),
  EgxStock('EOSB', 'العروبة للسمسرة', _fin),
  EgxStock('GRCA', 'جراند كابيتال', _fin),
  EgxStock('TYCN', 'تايكون القابضة', _fin),
  EgxStock('PRMH', 'برايم القابضة', _fin),
  EgxStock('HALN', 'إم إن تي هالان', _fin),
  EgxStock('ATLC', 'التوفيق للتأجير التمويلي', _fin),
  EgxStock('ICLE', 'الدولية للتأجير التمويلي', _fin),
  EgxStock('TWSA', 'تواصل للتخصيم', _fin),
  EgxStock('CPME', 'كاتاليست بارتنرز', _fin),
  EgxStock('KWIN', 'القاهرة الوطنية للاستثمار', _fin),
  EgxStock('MOIN', 'المهندس للتأمين', _fin),
  EgxStock('DEIN', 'دلتا للتأمين', _fin),
  EgxStock('AIHC', 'العربية للاستثمارات القابضة', _fin),
  EgxStock('BINV', 'بي إنفستمنتس القابضة', _fin),
  EgxStock('AMIA', 'العربية ملتقى للاستثمارات', _fin),
  EgxStock('MAAL', 'مرسيليا المصرية الخليجية', _fin),
  EgxStock('AFDI', 'الأهلي للتنمية والاستثمار', _fin),
  EgxStock('SEIG', 'السعودية المصرية للاستثمار والتمويل', _fin),
  EgxStock('ICID', 'الدولية للاستثمار والتنمية', _fin),
  EgxStock('AIDC', 'العربية للاستثمار والتنمية', _fin),

  // العقارات والإسكان
  EgxStock('TMGH', 'مجموعة طلعت مصطفى', _re),
  EgxStock('EMFD', 'إعمار مصر للتنمية', _re),
  EgxStock('ORHD', 'أوراسكوم للتنمية مصر', _re),
  EgxStock('PHDC', 'بالم هيلز للتعمير', _re),
  EgxStock('OCDI', 'سوديك', _re),
  EgxStock('HELI', 'مصر الجديدة للإسكان', _re),
  EgxStock('MASR', 'مدينة مصر للإسكان', _re),
  EgxStock('GPPL', 'جولدن بيراميدز بلازا', _re),
  EgxStock('ARAB', 'المطورون العرب القابضة', _re),
  EgxStock('UNIT', 'المتحدة للإسكان والتعمير', _re),
  EgxStock('AMER', 'مجموعة عامر القابضة', _re),
  EgxStock('ELKA', 'القاهرة للإسكان والتعمير', _re),
  EgxStock('GPIM', 'جي بي آي للنمو العمراني', _re),
  EgxStock('PRDC', 'بايونيرز بروبرتيز', _re),
  EgxStock('ZMID', 'زهراء المعادي', _re),
  EgxStock('BONY', 'بنيان للتنمية والتجارة', _re),
  EgxStock('CRST', 'كريست مارك للمقاولات والتطوير العقاري', _re),
  EgxStock('NARE', 'نعيم للتطوير العقاري', _re),
  EgxStock('EHDR', 'المصريين للإسكان والتنمية', _re),
  EgxStock('ELSH', 'الشمس للإسكان والتعمير', _re),
  EgxStock('IDRE', 'الإسماعيلية للتنمية والتطوير العقاري', _re),
  EgxStock('GGCC', 'الجيزة العامة للمقاولات والاستثمار العقاري', _re),
  EgxStock('UEGC', 'السعيد للمقاولات والاستثمار العقاري', _re),
  EgxStock('OBRI', 'العبور للاستثمار العقاري', _re),
  EgxStock('NHPS', 'الوطنية للإسكان للنقابات المهنية', _re),
  EgxStock('AREH', 'المصرية للمجمعات العقارية', _re),
  EgxStock('CCRS', 'الخليج الكندية للاستثمار العقاري', _re),
  EgxStock('RREI', 'العربية للاستثمار العقاري', _re),
  EgxStock('TANM', 'تنمية للاستثمار العقاري', _re),
  EgxStock('ELWA', 'الوادي للتنمية والاستثمار الدولي', _re),
  EgxStock('COPR', 'كوبر للاستثمار العقاري', _re),
  EgxStock('GIHD', 'الغربية الإسلامية للتنمية العمرانية', _re),
  EgxStock('SCTS', 'قناة السويس للتوطين التكنولوجي', _re),

  // المقاولات والصناعات الهندسية
  EgxStock('ORAS', 'أوراسكوم للإنشاء', _eng),
  EgxStock('SWDY', 'السويدي إليكتريك', _eng),
  EgxStock('ELEC', 'الكابلات الكهربائية المصرية', _eng),
  EgxStock('ENGC', 'الصناعات الهندسية للإنشاء (أيكون)', _eng),
  EgxStock('DAPH', 'التنمية والاستشارات الهندسية', _eng),
  EgxStock('MBEG', 'إم بي للهندسة', _eng),
  EgxStock('IEEC', 'المشروعات الصناعية والهندسية', _eng),
  EgxStock('NCCW', 'النصر للأعمال المدنية', _eng),
  EgxStock('EEII', 'العربية للصناعات الهندسية', _eng),
  EgxStock('AMII', 'العربية للصناعات المعدنية', _eng),
  EgxStock('ACRO', 'أكرو مصر', _eng),
  EgxStock('ARVA', 'العربية للمحابس', _eng),

  // الأسمنت ومواد البناء
  EgxStock('ARCC', 'العربية للأسمنت', _cem),
  EgxStock('SCEM', 'أسمنت سيناء', _cem),
  EgxStock('MBSC', 'مصر بني سويف للأسمنت', _cem),
  EgxStock('MCQE', 'مصر للأسمنت قنا', _cem),
  EgxStock('SVCE', 'جنوب الوادي للأسمنت', _cem),
  EgxStock('ALEX', 'أسمنت الإسكندرية', _cem),
  EgxStock('CERA', 'العربية للسيراميك (ريماس)', _cem),
  EgxStock('PRCL', 'العامة لمنتجات الخزف والصيني', _cem),
  EgxStock('ECAP', 'العز للسيراميك والبورسلين', _cem),
  EgxStock('LCSW', 'ليسيكو مصر', _cem),
  EgxStock('MEGM', 'الشرق الأوسط لصناعة الزجاج', _cem),

  // الحديد والمعادن
  EgxStock('ESRS', 'حديد عز', _met),
  EgxStock('IRON', 'الحديد والصلب المصرية', _met),
  EgxStock('ATQA', 'مصر الوطنية للصلب (عتاقة)', _met),
  EgxStock('ISMQ', 'الحديد والصلب للمناجم والمحاجر', _met),
  EgxStock('EGAL', 'مصر للألومنيوم', _met),
  EgxStock('ALUM', 'العربية للألومنيوم', _met),
  EgxStock('ASCM', 'أسيك للتعدين (أسكوم)', _met),

  // الكيماويات والأسمدة
  EgxStock('ABUK', 'أبوقير للأسمدة', _chem),
  EgxStock('MFPC', 'موبكو', _chem),
  EgxStock('FERC', 'فيرشيم مصر للأسمدة', _chem),
  EgxStock('EGCH', 'الصناعات الكيماوية المصرية (كيما)', _chem),
  EgxStock('ICFC', 'الدولية للأسمدة والكيماويات', _chem),
  EgxStock('KZPC', 'كفر الزيات للمبيدات والكيماويات', _chem),
  EgxStock('MICH', 'مصر للصناعات الكيماوية', _chem),
  EgxStock('SMFR', 'صمد مصر (إيجي فيرت)', _chem),
  EgxStock('SKPC', 'سيدي كرير للبتروكيماويات', _chem),
  EgxStock('EFIC', 'المصرية المالية والصناعية', _chem),
  EgxStock('RUBX', 'روبكس للبلاستيك والأكريليك', _chem),

  // الطاقة والبترول
  EgxStock('AMOC', 'الإسكندرية للزيوت المعدنية', _energy),
  EgxStock('TAQA', 'طاقة عربية', _energy),
  EgxStock('EGAS', 'مصر للغاز', _energy),
  EgxStock('MOIL', 'ماريديف لخدمات البترول', _energy),
  EgxStock('NDRL', 'الحفر الوطنية', _energy),
  EgxStock('KORA', 'كورا للطاقة', _energy),

  // الأغذية والمشروبات والزراعة
  EgxStock('EAST', 'الشرقية - إيسترن كومباني', _food),
  EgxStock('JUFO', 'جهينة للصناعات الغذائية', _food),
  EgxStock('EFID', 'إديتا للصناعات الغذائية', _food),
  EgxStock('DOMT', 'العربية للصناعات الغذائية (دومتي)', _food),
  EgxStock('OLFI', 'عبور لاند للصناعات الغذائية', _food),
  EgxStock('POUL', 'القاهرة للدواجن', _food),
  EgxStock('MPCO', 'المنصورة للدواجن', _food),
  EgxStock('ISMA', 'الإسماعيلية مصر للدواجن', _food),
  EgxStock('EPCO', 'مصر للدواجن', _food),
  EgxStock('SUGR', 'دلتا للسكر', _food),
  EgxStock('AFMC', 'مطاحن الإسكندرية', _food),
  EgxStock('WCDF', 'مطاحن مصر الوسطى والغربية', _food),
  EgxStock('UEFM', 'مطاحن مصر العليا', _food),
  EgxStock('EDFM', 'مطاحن شرق الدلتا', _food),
  EgxStock('CEFM', 'مطاحن مصر الوسطى', _food),
  EgxStock('MILS', 'مطاحن شمال القاهرة', _food),
  EgxStock('SCFM', 'مطاحن جنوب القاهرة والجيزة', _food),
  EgxStock('GSSC', 'العامة للصوامع والتخزين', _food),
  EgxStock('AJWA', 'أجواء للصناعات الغذائية', _food),
  EgxStock('INFI', 'الإسماعيلية الوطنية للصناعات الغذائية', _food),
  EgxStock('ALRA', 'أطلس للاستثمار والصناعات الغذائية', _food),
  EgxStock('ADPC', 'العربية لمنتجات الألبان (باندا)', _food),
  EgxStock('GOUR', 'جورميه إيجيبت', _food),
  EgxStock('SNFC', 'الشرقية الوطنية للأمن الغذائي', _food),
  EgxStock('IFAP', 'الدولية للمحاصيل الزراعية', _food),
  EgxStock('GGRN', 'جو جرين للاستثمار الزراعي', _food),
  EgxStock('LUTS', 'لوتس للاستثمارات الزراعية', _food),
  EgxStock('AALR', 'العامة لاستصلاح الأراضي', _food),
  EgxStock('EALR', 'العربية لاستصلاح الأراضي', _food),
  EgxStock('WKOL', 'وادي كوم أمبو لاستصلاح الأراضي', _food),
  EgxStock('KRDI', 'نهر الخير للتنمية الزراعية', _food),
  EgxStock('NEDA', 'شمال الصعيد للتنمية والإنتاج الزراعي', _food),
  EgxStock('ELNA', 'النصر للمحاصيل الزراعية', _food),
  EgxStock('ZEOT', 'الزيوت المستخلصة ومشتقاتها', _food),
  EgxStock('MOSC', 'مصر للزيوت والصابون', _food),
  EgxStock('COSG', 'القاهرة للزيوت والصابون', _food),

  // الأدوية والرعاية الصحية
  EgxStock('BIOC', 'جلاكسو سميثكلاين', _pharma),
  EgxStock('PHAR', 'إيبيكو (المصرية الدولية للأدوية)', _pharma),
  EgxStock('ISPH', 'ابن سينا فارما', _pharma),
  EgxStock('CLHO', 'كليوباترا للمستشفيات', _pharma),
  EgxStock('RMDA', 'العاشر من رمضان للأدوية (راميدا)', _pharma),
  EgxStock('MIPH', 'مينافارم', _pharma),
  EgxStock('AMES', 'الإسكندرية للخدمات الطبية', _pharma),
  EgxStock('CPCI', 'القاهرة للأدوية', _pharma),
  EgxStock('MPCI', 'ممفيس للأدوية', _pharma),
  EgxStock('AXPH', 'الإسكندرية للأدوية', _pharma),
  EgxStock('NIPH', 'النيل للأدوية', _pharma),
  EgxStock('ADCI', 'العربية للأدوية', _pharma),
  EgxStock('SIPC', 'سبأ الدولية للأدوية', _pharma),
  EgxStock('OCPH', 'أكتوبر فارما', _pharma),
  EgxStock('MCRO', 'ماكرو جروب للأدوية', _pharma),
  EgxStock('NINH', 'مستشفى النزهة الدولي', _pharma),
  EgxStock('PHGC', 'بريميوم هيلثكير', _pharma),
  EgxStock('SPMD', 'سبيد ميديكال', _pharma),
  EgxStock('FCMD', 'الدولية للصناعات الطبية', _pharma),
  EgxStock('MEPA', 'العبوات الطبية', _pharma),

  // الغزل والنسيج والملابس
  EgxStock('ORWE', 'النساجون الشرقيون', _tex),
  EgxStock('SPIN', 'الإسكندرية للغزل والنسيج', _tex),
  EgxStock('KABO', 'النصر للملابس والمنسوجات (كابو)', _tex),
  EgxStock('DSCW', 'دايس للملابس الجاهزة', _tex),
  EgxStock('GTWL', 'جولدن تكستايلز', _tex),
  EgxStock('APSW', 'العربية بولفارا للغزل والنسيج', _tex),
  EgxStock('ACGC', 'العربية لحليج الأقطان', _tex),
  EgxStock('CFGH', 'كونكريت فاشون', _tex),
  EgxStock('GTEX', 'جي تكس للاستثمارات', _tex),

  // السياحة والفنادق
  EgxStock('EGTS', 'المصرية للمنتجعات السياحية', _tour),
  EgxStock('MHOT', 'مصر للفنادق', _tour),
  EgxStock('PHTV', 'بيراميزا للفنادق والمنتجعات', _tour),
  EgxStock('SPHT', 'الشمس بيراميدز للفنادق', _tour),
  EgxStock('SDTI', 'شرم دريمز للاستثمار السياحي', _tour),
  EgxStock('MENA', 'مينا للاستثمار السياحي والعقاري', _tour),
  EgxStock('ROTO', 'رواد السياحة', _tour),
  EgxStock('RTVC', 'ريمكو لإنشاء القرى السياحية', _tour),
  EgxStock('TRTO', 'ترانس أوشنز للسياحة', _tour),
  EgxStock('MMAT', 'مرسى مرسى علم للتنمية السياحية', _tour),

  // الاتصالات والتكنولوجيا
  EgxStock('ETEL', 'المصرية للاتصالات', _tech),
  EgxStock('FWRY', 'فوري لتكنولوجيا البنوك', _tech),
  EgxStock('EFIH', 'إي فاينانس', _tech),
  EgxStock('EGSA', 'النايل سات', _tech),
  EgxStock('RACC', 'راية لخدمة العملاء', _tech),
  EgxStock('DGTZ', 'ديجيتايز للاستثمار والتكنولوجيا', _tech),

  // النقل والخدمات اللوجستية
  EgxStock('ALCN', 'الإسكندرية لتداول الحاويات', _trans),
  EgxStock('CSAG', 'القناة للتوكيلات الملاحية', _trans),
  EgxStock('ETRS', 'المصرية للنقل والخدمات التجارية', _trans),
  EgxStock('POCO', 'بورسعيد لتداول الحاويات', _trans),
  EgxStock('DCCC', 'دمياط لتداول الحاويات', _trans),

  // التعليم
  EgxStock('TALM', 'تعليم لخدمات الإدارة', _edu),
  EgxStock('CIRA', 'سيرا للتعليم', _edu),
  EgxStock('CAED', 'القاهرة للخدمات التعليمية', _edu),
  EgxStock('MOED', 'المصرية لنظم التعليم الحديثة', _edu),

  // ورق وتعبئة وصناعات متنوعة
  EgxStock('UNIP', 'يونيفرسال للورق ومواد التعبئة', _misc),
  EgxStock('RAKT', 'راكتا لصناعة الورق', _misc),
  EgxStock('NAPR', 'الطباعة الوطنية', _misc),
  EgxStock('DTPP', 'دلتا للطباعة والتغليف', _misc),
  EgxStock('EPPK', 'الأهرام للطباعة والتغليف', _misc),
  EgxStock('GBCO', 'جي بي كورب (غبور)', _misc),
  EgxStock('MFSC', 'مصر للأسواق الحرة', _misc),
  EgxStock('GDWA', 'جدوى للتنمية الصناعية', _misc),
  EgxStock('MTIE', 'إم إم جروب للصناعة والتجارة الدولية', _misc),
  EgxStock('MPRC', 'مدينة الإنتاج الإعلامي', _misc),
  EgxStock('GMCI', 'جي إم سي جروب', _misc),
];

/// رموز بديلة على ياهو لو الرمز الأساسي ما رجّعش بيانات.
const kYahooAlt = <String, String>{
  'CCAP': 'EKHO',
  'MASR': 'MNHD',
  'GBCO': 'AUTO',
  'AUTO': 'GBCO',
  'BINV': 'BCAP',
  'AIHC': 'AIH',
};

final Map<String, EgxStock> kEgxIndex = {
  for (final s in kEgxStocks) s.symbol: s,
};

String sectorOf(String symbol) => kEgxIndex[symbol]?.sector ?? kOtherSector;
