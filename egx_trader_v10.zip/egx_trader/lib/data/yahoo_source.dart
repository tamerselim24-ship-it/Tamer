import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models.dart';
import 'data_source.dart';
import 'egx_universe.dart';

/// مصدر Yahoo Finance (endpoints غير رسمية). الأسهم المصرية برمز `XXXX.CA`.
///
/// تنبيهات:
/// - ما اتجرّبش من بيئة التطوير (الوصول للشبكة كان محجوب)، اختبره على جهازك.
/// - ياهو ممكن يغيّر أو يحجب الـ endpoints في أي وقت، وبيانات EGX عليه
///   ممكن تكون متأخرة أو ناقصة. البيانات المالية خصوصًا ناقصة لأسهم كتير.
/// - لا يعمل على الويب (CORS)، مخصص للموبايل.
class YahooDataSource implements MarketDataSource {
  YahooDataSource({Map<String, String>? symbols, http.Client? client})
      : symbols = symbols ?? defaultSymbols,
        _client = client ?? http.Client();

  /// الرمز → الاسم. زوّد القائمة براحتك.
  final Map<String, String> symbols;
  final http.Client _client;

  /// كل الأسهم المعروفة (من egx_universe.dart).
  static final Map<String, String> defaultSymbols = {
    for (final e in kEgxStocks) e.symbol: e.name,
  };

  static const _host = 'query1.finance.yahoo.com';
  static const _ua = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',
  };

  String? _cookie, _crumb;

  @override
  bool get isDemo => false;

  @override
  String? get lastError => null;

  String _y(String symbol) => '$symbol.CA';

  // ───────────── الشارت (أسعار + تاريخ) ─────────────

  Future<List<Candle>> _candles(String symbol, String range) async {
    try {
      return await _candlesFor(symbol, range);
    } catch (e) {
      final alt = kYahooAlt[symbol];
      if (alt == null) rethrow;
      return _candlesFor(alt, range);
    }
  }

  Future<List<Candle>> _candlesFor(String symbol, String range) async {
    http.Response? res;
    for (final host in const ['query1.finance.yahoo.com', 'query2.finance.yahoo.com']) {
      final r = await _client
          .get(Uri.https(host, '/v8/finance/chart/${_y(symbol)}', {'range': range, 'interval': '1d'}),
              headers: _ua)
          .timeout(const Duration(seconds: 15));
      res = r;
      if (r.statusCode == 200) break;
    }
    if (res == null || res.statusCode != 200) {
      throw Exception('Yahoo chart HTTP ${res?.statusCode}');
    }
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    final result = (json['chart']?['result'] as List?)?.firstOrNull as Map<String, dynamic>?;
    if (result == null) throw Exception('لا توجد بيانات لـ $symbol');

    final ts = (result['timestamp'] as List?)?.cast<num>() ?? const <num>[];
    final q = (result['indicators']?['quote'] as List?)?.firstOrNull as Map<String, dynamic>?;
    if (q == null) throw Exception('بيانات ناقصة لـ $symbol');
    List<num?> col(String k) => (q[k] as List?)?.cast<num?>() ?? const <num?>[];
    final o = col('open'), h = col('high'), l = col('low'), c = col('close'), v = col('volume');

    final out = <Candle>[];
    for (var i = 0; i < ts.length; i++) {
      final close = i < c.length ? c[i] : null;
      if (close == null) continue;
      double pick(List<num?> a) => (i < a.length ? a[i] : null)?.toDouble() ?? close.toDouble();
      out.add(Candle(
        date: DateTime.fromMillisecondsSinceEpoch(ts[i].toInt() * 1000, isUtc: true).toLocal(),
        open: pick(o),
        high: pick(h),
        low: pick(l),
        close: close.toDouble(),
        volume: (i < v.length ? v[i] : null)?.toDouble() ?? 0,
      ));
    }
    if (out.isEmpty) throw Exception('لا توجد شموع لـ $symbol');
    return out;
  }

  @override
  Future<List<Quote>> fetchQuotes({QuotesProgress? onProgress}) async {
    String? firstError;
    final entries = symbols.entries.toList();
    final quotes = <Quote>[];
    var done = 0;
    // على دفعات علشان ياهو ما يرفضش الطلبات المتزامنة الكتيرة.
    for (var i = 0; i < entries.length; i += 10) {
      final chunk = entries.skip(i).take(10);
      final res = await Future.wait(chunk.map<Future<Quote?>>((e) async {
        try {
          return await _quoteFor(e.key, e.value);
        } catch (err) {
          firstError ??= err.toString();
          return null;
        }
      }));
      quotes.addAll(res.whereType<Quote>());
      done += chunk.length;
      onProgress?.call(List<Quote>.unmodifiable(quotes), done, entries.length);
    }
    if (quotes.isEmpty) {
      throw Exception('ياهو لم يرجّع أي أسعار (${firstError ?? "بدون تفاصيل"})');
    }
    return quotes;
  }

  Future<Quote> _quoteFor(String symbol, String name) async {
    final c = await _candles(symbol, '5d');
    final last = c.last;
    final prev = c.length > 1 ? c[c.length - 2].close : last.open;
    return Quote(
      symbol: symbol,
      name: name,
      sector: sectorOf(symbol),
      last: last.close,
      prevClose: prev,
      open: last.open,
      high: last.high,
      low: last.low,
      volume: last.volume,
      value: last.volume * last.close,
      asOf: last.date,
    );
  }

  /// null = ياهو معندوش السهم ده. أي خطأ تاني (شبكة…) بيتعمله throw.
  @override
  Future<Quote?> lookup(String symbol) async {
    try {
      return await _quoteFor(symbol, symbols[symbol] ?? symbol);
    } catch (e) {
      final m = e.toString();
      if (m.contains('404') || m.contains('لا توجد')) return null;
      rethrow;
    }
  }

  @override
  Future<List<Candle>> fetchHistory(String symbol, {int days = 260}) async {
    final all = await _candles(symbol, '2y');
    return all.length <= days ? all : all.sublist(all.length - days);
  }

  // ───────────── البيانات المالية (محتاجة cookie + crumb) ─────────────

  Future<void> _auth() async {
    if (_crumb != null) return;
    final r1 = await _client
        .get(Uri.parse('https://fc.yahoo.com'), headers: _ua)
        .timeout(const Duration(seconds: 15));
    final setCookie = r1.headers['set-cookie'];
    if (setCookie == null) throw Exception('تعذّر الحصول على cookie من ياهو');
    final cookie = setCookie.split(';').first;
    final r2 = await _client
        .get(Uri.https(_host, '/v1/test/getcrumb'), headers: {..._ua, 'Cookie': cookie})
        .timeout(const Duration(seconds: 15));
    if (r2.statusCode != 200 || r2.body.isEmpty) throw Exception('تعذّر الحصول على crumb');
    _cookie = cookie;
    _crumb = r2.body;
  }

  double? _raw(Map<String, dynamic>? m, String key) {
    final v = m?[key];
    if (v is Map) return (v['raw'] as num?)?.toDouble();
    return null;
  }

  @override
  Future<Fundamentals?> fetchFundamentals(String symbol) async {
    for (var attempt = 0; attempt < 2; attempt++) {
      await _auth();
      final res = await _client
          .get(
            Uri.https(_host, '/v10/finance/quoteSummary/${_y(symbol)}', {
              'modules': 'defaultKeyStatistics,financialData,summaryDetail',
              'crumb': _crumb!,
            }),
            headers: {..._ua, 'Cookie': _cookie!},
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 401 || res.statusCode == 403) {
        _crumb = null; // نجدّد الجلسة ونعيد مرة واحدة
        continue;
      }
      if (res.statusCode == 404) return null; // لا توجد بيانات مالية لهذا السهم
      if (res.statusCode != 200) throw Exception('Yahoo summary HTTP ${res.statusCode}');

      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final r = (json['quoteSummary']?['result'] as List?)?.firstOrNull as Map<String, dynamic>?;
      if (r == null) return null;
      final ks = r['defaultKeyStatistics'] as Map<String, dynamic>?;
      final fd = r['financialData'] as Map<String, dynamic>?;
      final sd = r['summaryDetail'] as Map<String, dynamic>?;

      final bvps = _raw(ks, 'bookValue');
      final shares = _raw(ks, 'sharesOutstanding');
      final growth = _raw(fd, 'revenueGrowth');
      final f = Fundamentals(
        eps: _raw(ks, 'trailingEps'),
        bookValuePerShare: bvps,
        dividendPerShare: _raw(sd, 'dividendRate') ?? _raw(sd, 'trailingAnnualDividendRate'),
        revenue: _raw(fd, 'totalRevenue'),
        netProfit: _raw(ks, 'netIncomeToCommon'),
        totalEquity: (bvps != null && shares != null) ? bvps * shares : null,
        totalDebt: _raw(fd, 'totalDebt'),
        sharesOutstanding: shares,
        revenueGrowthPct: growth == null ? null : growth * 100,
      );
      final empty = f.eps == null &&
          f.bookValuePerShare == null &&
          f.revenue == null &&
          f.netProfit == null &&
          f.totalDebt == null;
      return empty ? null : f;
    }
    throw Exception('فشلت مصادقة ياهو');
  }
}
