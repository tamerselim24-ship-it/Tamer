import '../analysis/fundamental.dart';
import '../analysis/liquidity.dart';
import '../analysis/screener.dart';
import '../analysis/technical.dart';
import '../models.dart';
import '../util.dart';

const aiSystemPrompt = '''
أنت محلل أسواق مالية متخصص في البورصة المصرية (EGX). هتستلم بيانات سهم واحد (أسعار، مؤشرات فنية، سيولة، نسب مالية) محسوبة بالفعل. حلّلها بدقة وبعربي واضح ومبسّط (ممكن عامية مصرية خفيفة).

التزم بالآتي:
- اعتمد فقط على الأرقام المرفقة، ولا تخترع أرقام أو أخبار أو أحداث غير موجودة.
- لو بيانات ناقصة أو غير متاحة، قول كده صراحة.
- لو آخر جلسة في البيانات أقدم من تاريخ النهارده بأكتر من جلسة تداول (الأحد–الخميس)، نبّه إن التحليل مبني على بيانات متأخرة.
- اكتب بنص عادي بدون Markdown (لا تستخدم # ولا ** ولا جداول). العنوان يكون سطر لوحده، والنقاط تبدأ بشرطة (-).
- مفيش توصية شراء أو بيع قاطعة. اعرض سيناريوهات ومستويات ومخاطر.
- اختم بسطر تنبيه إن ده تحليل آلي وليس نصيحة استثمارية.
''';

String _n(double? v, [int d = 2]) => v == null ? 'غير متاح' : fmtNum(v, d);

String _date(DateTime d) => d.toIso8601String().substring(0, 10);

String _chg(List<double> c, int n) {
  if (c.length <= n) return 'غير متاح';
  final base = c[c.length - 1 - n];
  if (base == 0) return 'غير متاح';
  return fmtPct((c.last / base - 1) * 100);
}

String _verdictAr(Verdict v) => switch (v) {
      Verdict.buy => 'إيجابي',
      Verdict.sell => 'سلبي',
      Verdict.neutral => 'محايد',
    };

String buildAnalysisPrompt({
  required Quote quote,
  required List<Candle> candles,
  Fundamentals? fundamentals,
  required bool isDemo,
}) {
  final out = StringBuffer();
  void line(String s) => out.writeln(s);

  line('السهم: ${quote.symbol} - ${quote.name}');
  line('تاريخ النهارده: ${_date(DateTime.now())}');
  if (isDemo) {
    line('تنبيه: البيانات دي تجريبية مش حقيقية، اذكر ده في أول التحليل.');
  }
  line('');
  line('== السعر ==');
  line('آخر سعر: ${fmtNum(quote.last)} جنيه');
  line('التغير عن الإغلاق السابق: ${fmtNum(quote.change)} (${fmtPct(quote.changePct)})');
  line('الافتتاح ${fmtNum(quote.open)} | الأعلى ${fmtNum(quote.high)} | '
      'الأدنى ${fmtNum(quote.low)} | الإغلاق السابق ${fmtNum(quote.prevClose)}');
  line('حجم التداول: ${fmtCompact(quote.volume)} سهم | '
      'قيمة التداول: ${fmtCompact(quote.value)} جنيه');

  if (candles.isNotEmpty) {
    final closes = [for (final c in candles) c.close];
    var hi = candles.first.high, lo = candles.first.low;
    for (final c in candles) {
      if (c.high > hi) hi = c.high;
      if (c.low < lo) lo = c.low;
    }
    line('');
    line('== الأداء التاريخي (${candles.length} جلسة من '
        '${_date(candles.first.date)} إلى ${_date(candles.last.date)}) ==');
    line('أعلى سعر في الفترة: ${fmtNum(hi)} | أدنى سعر: ${fmtNum(lo)}');
    line('التغير: شهر ${_chg(closes, 21)} | 3 شهور ${_chg(closes, 63)} | '
        '6 شهور ${_chg(closes, 126)} | سنة ${_chg(closes, 252)}');

    final summary = analyzeTechnical(candles);
    if (summary.signals.isNotEmpty) {
      final m = macd(closes);
      final bb = bollinger(closes);
      final lv = pivotLevels(candles);
      line('');
      line('== التحليل الفني ==');
      line('SMA20=${_n(sma(closes, 20).last)} | SMA50=${_n(sma(closes, 50).last)} | '
          'SMA200=${_n(sma(closes, 200).last)}');
      line('RSI(14)=${_n(rsi(closes).last, 1)}');
      line('MACD=${_n(m.line.last, 3)} | Signal=${_n(m.signal.last, 3)} | '
          'Histogram=${_n(m.hist.last, 3)}');
      line('بولينجر: علوي=${_n(bb.upper.last)} | وسط=${_n(bb.mid.last)} | '
          'سفلي=${_n(bb.lower.last)}');
      line('مقاومة: ${lv.resistance.isEmpty ? "غير محددة" : lv.resistance.map(fmtNum).join(" / ")}');
      line('دعم: ${lv.support.isEmpty ? "غير محدد" : lv.support.map(fmtNum).join(" / ")}');
      line('الإشارات: إيجابية ${summary.buy} | سلبية ${summary.sell} | '
          'محايدة ${summary.neutral} => ${summary.overall}');
      for (final s in summary.signals) {
        line('- ${s.name}: ${_verdictAr(s.verdict)} (${s.detail})');
      }
    }

    final liq = analyzeLiquidity(candles);
    if (liq != null) {
      line('');
      line('== السيولة ==');
      line('متوسط الحجم 20 يوم: ${fmtCompact(liq.avgVolume20)} سهم | '
          'متوسط قيمة التداول: ${fmtCompact(liq.avgValue20)} جنيه');
      line('حجم آخر جلسة ÷ المتوسط = ${fmtNum(liq.volumeRatio)}x (${liq.activity})');
      line('OBV: ${liq.obvRising ? "صاعد (تجميع)" : "هابط (تصريف)"} | '
          'MFI(14)=${_n(liq.mfi, 1)}');
    }
  } else {
    line('');
    line('السجل التاريخي غير متاح، فمفيش تحليل فني أو سيولة تاريخية.');
  }

  line('');
  line('== التحليل المالي ==');
  final f = fundamentals;
  if (f == null) {
    line('البيانات المالية غير متاحة لهذا السهم.');
  } else {
    if (f.revenue != null) line('الإيرادات: ${fmtCompact(f.revenue!)}');
    if (f.netProfit != null) line('صافي الربح: ${fmtCompact(f.netProfit!)}');
    if (f.eps != null) line('ربحية السهم EPS: ${fmtNum(f.eps!)}');
    for (final r in analyzeFundamentals(quote, f)) {
      line('- ${r.name}: ${r.value}${r.note.isEmpty ? "" : " (${r.note})"}');
    }
  }

  line('');
  line('المطلوب تحليل منظم بالترتيب ده، كل قسم بعنوان في سطر لوحده:');
  line('الملخص (سطرين)');
  line('الصورة الفنية');
  line('السيولة والحجم');
  line('الصورة المالية');
  line('سيناريو صعودي وسيناريو هبوطي (بمستويات من البيانات المرفقة فقط)');
  line('المخاطر ونقاط المتابعة');
  line('الخلاصة');
  return out.toString();
}

String _pickBlock(Pick p, int rank) {
  final b = StringBuffer();
  b.writeln('$rank) ${p.quote.symbol} - ${p.quote.name} | النقاط ${p.score}/100');
  b.writeln('   آخر إغلاق ${fmtNum(p.price)} (${fmtPct(p.quote.changePct)})');
  b.writeln('   منطقة الدخول ${fmtNum(p.entryLow)} - ${fmtNum(p.entryHigh)} | '
      'وقف ${fmtNum(p.stop)} | هدف1 ${fmtNum(p.target1)} | هدف2 ${fmtNum(p.target2)} | '
      'عائد/مخاطرة 1:${fmtNum(p.rewardRisk, 1)}');
  b.writeln('   ملاحظة الدخول: ${p.entryNote}');
  for (final r in p.reasons) {
    b.writeln('   + $r');
  }
  for (final w in p.warnings) {
    b.writeln('   ! $w');
  }
  return b.toString();
}

/// بيطلب من الـ AI يشرح الترشيحات اللي طلعت من الفاحص، من غير ما يغيّر الأرقام.
String buildPicksPrompt(ScanResult r) {
  final out = StringBuffer();
  void line(String s) => out.writeln(s);
  line('تاريخ النهارده: ${_date(DateTime.now())}');
  final sd = r.sessionDate;
  line('آخر جلسة في البيانات: ${sd == null ? "غير معروف" : _date(sd)} '
      '(بيانات ياهو، ممكن تكون متأخرة يوم عن السوق).');
  line('اتفحص ${r.scanned} سهم بس من القايمة المحدودة اللي في التطبيق (مش السوق كله).');
  line('');
  line('== ترشيحات المضاربة (قصيرة المدى) ==');
  if (r.trade.isEmpty) line('مفيش أسهم استوفت الشروط.');
  for (var i = 0; i < r.trade.length; i++) {
    out.write(_pickBlock(r.trade[i], i + 1));
  }
  line('');
  line('== ترشيحات الاستثمار (متوسطة وطويلة المدى) ==');
  if (r.invest.isEmpty) line('مفيش أسهم استوفت الشروط.');
  for (var i = 0; i < r.invest.length; i++) {
    out.write(_pickBlock(r.invest[i], i + 1));
  }
  line('');
  line('ملاحظات: مستويات الدخول والوقف والأهداف محسوبة بقواعد ثابتة من تذبذب السهم (ATR) '
      'والدعم والمقاومة. اشرحها ولا تغيّر أي رقم ولا تضيف أرقام جديدة.');
  line('المطلوب: لكل سهم في القايمتين، سطرين أو تلاتة: ليه مرشّح دلوقتي بكلام بسيط، '
      'وإيه اللي يلغي الفكرة، وإيه اللي تتابعه. لو القايمة فاضية قول ده وفسّره.');
  line('في الآخر: ملخص قصير للصورة العامة من القايمة دي، وتنبيه إن دي أفكار للدراسة مش نصيحة استثمارية.');
  return out.toString();
}
