import 'dart:math' as math;

import '../data/data_source.dart';
import '../models.dart';
import '../util.dart';
import 'liquidity.dart';
import 'technical.dart';

/// فاحص الأسهم: بيحسب نقاط (0–100) لكل سهم بقواعد ثابتة وشفافة، مش توقّعات.
/// مفيش اختبار تاريخي (backtest) للقواعد دي، فاعتبرها مرشّح أولي مش إشارة مضمونة.

enum PickMode { trade, invest }

class Pick {
  const Pick({
    required this.quote,
    required this.mode,
    required this.score,
    required this.reasons,
    required this.warnings,
    required this.price,
    required this.entryLow,
    required this.entryHigh,
    required this.stop,
    required this.target1,
    required this.target2,
    required this.entryNote,
    required this.horizon,
    required this.asOf,
    this.hasFundamentals = false,
  });

  final Quote quote;
  final PickMode mode;
  final int score;
  final List<String> reasons;
  final List<String> warnings;
  final double price, entryLow, entryHigh, stop, target1, target2;
  final String entryNote, horizon;
  final DateTime asOf;
  final bool hasFundamentals;

  double get riskPct => (price - stop) / price * 100;
  double get gain1Pct => (target1 / price - 1) * 100;
  double get gain2Pct => (target2 / price - 1) * 100;
  double get rewardRisk => price - stop <= 0 ? 0 : (target1 - price) / (price - stop);
}

class ScanResult {
  const ScanResult({
    required this.trade,
    required this.invest,
    required this.scanned,
    required this.failed,
    required this.time,
    this.sessionDate,
  });

  final List<Pick> trade;
  final List<Pick> invest;
  final int scanned;
  final int failed;
  final DateTime time;
  final DateTime? sessionDate;
}

class _Score {
  int pts = 0;
  final reasons = <String>[];
  final warnings = <String>[];

  void add(int p, String why) {
    pts += p;
    reasons.add(why);
  }

  void sub(int p, String why) {
    pts -= p;
    warnings.add(why);
  }
}

double? _roc(List<double> c, int n) {
  if (c.length <= n) return null;
  final base = c[c.length - 1 - n];
  return base == 0 ? null : (c.last / base - 1) * 100;
}

class _Stat {
  _Stat(this.quote, this.candles) {
    closes = [for (final x in candles) x.close];
    last = closes.last;
    prev = closes.length > 1 ? closes[closes.length - 2] : last;
    dayPct = prev == 0 ? 0 : (last / prev - 1) * 100;
    s20 = sma(closes, 20).last;
    s50 = sma(closes, 50).last;
    s200 = sma(closes, 200).last;
    rsiV = rsi(closes).last;
    final m = macd(closes);
    macdLine = m.line.last;
    macdSig = m.signal.last;
    histNow = m.hist.last;
    histPrev = m.hist.length > 1 ? m.hist[m.hist.length - 2] : null;
    final a = atr(candles).last;
    atrV = math.max(a ?? last * 0.02, last * 0.01);
    liq = analyzeLiquidity(candles);
    levels = pivotLevels(candles);
    roc5 = _roc(closes, 5);
    roc126 = _roc(closes, 126);
    asOf = candles.last.date;

    var yh = candles.first.high;
    final from = math.max(0, candles.length - 252);
    for (var i = from; i < candles.length; i++) {
      yh = math.max(yh, candles[i].high);
    }
    yearHigh = yh;

    if (candles.length >= 22) {
      var h = candles[candles.length - 21].high;
      for (var i = candles.length - 21; i <= candles.length - 2; i++) {
        h = math.max(h, candles[i].high);
      }
      hi20 = h;
    } else {
      hi20 = null;
    }
  }

  final Quote quote;
  final List<Candle> candles;
  late final List<double> closes;
  late final double last, prev, dayPct, atrV, yearHigh;
  late final double? s20, s50, s200, rsiV, macdLine, macdSig, histNow, histPrev;
  late final double? hi20, roc5, roc126;
  late final LiquidityStats? liq;
  late final Levels levels;
  late final DateTime asOf;
  _Score trade = _Score();
  _Score invest = _Score();
  bool hasFund = false;
}

// ───────────── النقاط ─────────────

_Score _tradeScore(_Stat s) {
  final sc = _Score();
  final last = s.last;
  final s20 = s.s20, s50 = s.s50, r = s.rsiV;

  if (s20 != null && last > s20) sc.add(12, 'السعر فوق متوسط 20 يوم');
  if (s20 != null && s50 != null && s20 > s50) {
    sc.add(8, 'متوسط 20 فوق متوسط 50 (اتجاه صاعد قصير المدى)');
  }

  final ml = s.macdLine, ms = s.macdSig;
  if (ml != null && ms != null && ml > ms) {
    sc.add(10, 'MACD إيجابي (الخط فوق خط الإشارة)');
    final hn = s.histNow, hp = s.histPrev;
    if (hn != null && hp != null && hn > hp) sc.add(5, 'زخم MACD بيزيد');
  }

  if (r != null) {
    if (r >= 50 && r <= 70) {
      sc.add(15, 'RSI ${fmtNum(r, 1)} (زخم صحي)');
    } else if (r > 70 && r <= 78) {
      sc.add(5, 'RSI ${fmtNum(r, 1)} (مرتفع لكن مش مبالغ فيه)');
    } else if (r > 78) {
      sc.sub(10, 'RSI ${fmtNum(r, 1)} مبالغ فيه (خطر تصحيح)');
    } else if (r < 45) {
      sc.sub(10, 'RSI ${fmtNum(r, 1)} ضعيف');
    }
  }

  final liq = s.liq;
  if (liq != null) {
    if (liq.volumeRatio >= 2) {
      sc.add(20, 'حجم تداول استثنائي (${fmtNum(liq.volumeRatio, 1)}x المتوسط)');
    } else if (liq.volumeRatio >= 1.3) {
      sc.add(12, 'حجم تداول أعلى من المعتاد (${fmtNum(liq.volumeRatio, 1)}x)');
    } else if (liq.volumeRatio < 0.7) {
      sc.sub(8, 'حجم تداول ضعيف');
    }
    if (liq.obvRising) sc.add(5, 'OBV صاعد (تجميع)');
    if (liq.avgValue20 < 1e6) sc.sub(15, 'سيولة يومية ضعيفة (أقل من مليون جنيه)');
  }

  final hi = s.hi20;
  if (hi != null) {
    if (last >= hi) {
      sc.add(15, 'كسر أعلى مستوى في 20 يوم (${fmtNum(hi)})');
    } else if (last >= hi * 0.98) {
      sc.add(8, 'قريب من أعلى مستوى في 20 يوم (${fmtNum(hi)})');
    }
  }

  final r5 = s.roc5;
  if (r5 != null && r5 > 0) sc.add(5, 'مكسب ${fmtNum(r5, 1)}% خلال 5 جلسات');
  if (s50 != null && last < s50) sc.sub(10, 'السعر تحت متوسط 50 يوم');
  if (s.dayPct > 7) {
    sc.sub(5, 'ارتفع ${fmtNum(s.dayPct, 1)}% في جلسة واحدة (خطر مطاردة السعر)');
  }
  return sc;
}

_Score _investScore(_Stat s) {
  final sc = _Score();
  final last = s.last;
  final s50 = s.s50, s200 = s.s200, r = s.rsiV;

  if (s200 != null) {
    if (last > s200) {
      sc.add(15, 'السعر فوق متوسط 200 يوم (اتجاه طويل المدى صاعد)');
    } else {
      sc.sub(15, 'السعر تحت متوسط 200 يوم');
    }
    if (s50 != null && s50 > s200) sc.add(10, 'متوسط 50 فوق متوسط 200');
  }
  if (s50 != null && last > s50) sc.add(8, 'السعر فوق متوسط 50 يوم');

  final r6 = s.roc126;
  if (r6 != null) {
    if (r6 > 15) {
      sc.add(14, 'أداء قوي خلال 6 شهور (+${fmtNum(r6, 1)}%)');
    } else if (r6 > 0) {
      sc.add(7, 'أداء إيجابي خلال 6 شهور (+${fmtNum(r6, 1)}%)');
    } else {
      sc.sub(5, 'أداء سلبي خلال 6 شهور (${fmtNum(r6, 1)}%)');
    }
  }

  if (r != null && r >= 40 && r <= 68) {
    sc.add(8, 'RSI ${fmtNum(r, 1)} (متوازن، مش مبالغ فيه)');
  }
  if (r != null && r > 75) sc.sub(8, 'RSI ${fmtNum(r, 1)} مرتفع، الأفضل تستنى تهدئة');

  final ml = s.macdLine;
  if (ml != null && ml > 0) sc.add(5, 'MACD فوق الصفر');
  if (last >= s.yearHigh * 0.85) sc.add(5, 'قريب من أعلى سعر في سنة');

  final liq = s.liq;
  if (liq != null && liq.avgValue20 < 5e5) sc.sub(10, 'سيولة يومية ضعيفة جدًا');
  return sc;
}

void _fundScore(_Score sc, double price, Fundamentals f) {
  final eps = f.eps;
  if (eps != null) {
    if (eps > 0) {
      final pe = price / eps;
      if (pe <= 12) {
        sc.add(10, 'مكرر ربحية منخفض (P/E ${fmtNum(pe, 1)})');
      } else if (pe <= 18) {
        sc.add(5, 'مكرر ربحية معقول (P/E ${fmtNum(pe, 1)})');
      } else if (pe > 30) {
        sc.sub(5, 'مكرر ربحية مرتفع (P/E ${fmtNum(pe, 1)})');
      }
    } else {
      sc.sub(10, 'الشركة خاسرة (EPS سالب)');
    }
  }
  final bv = f.bookValuePerShare;
  if (bv != null && bv > 0) {
    final pb = price / bv;
    if (pb <= 1.5) sc.add(5, 'قريب من القيمة الدفترية (P/B ${fmtNum(pb, 1)})');
  }
  final np = f.netProfit, eq = f.totalEquity;
  if (np != null && eq != null && eq > 0) {
    final roe = np / eq * 100;
    if (roe >= 15) {
      sc.add(10, 'عائد قوي على حقوق الملكية (ROE ${fmtNum(roe, 1)}%)');
    } else if (roe >= 10) {
      sc.add(5, 'عائد مقبول على حقوق الملكية (ROE ${fmtNum(roe, 1)}%)');
    }
  }
  final dps = f.dividendPerShare;
  if (dps != null && price > 0 && dps / price * 100 >= 3) {
    sc.add(5, 'عائد توزيعات ${fmtNum(dps / price * 100, 1)}%');
  }
  final debt = f.totalDebt;
  if (debt != null && eq != null && eq > 0) {
    final de = debt / eq;
    if (de < 1) {
      sc.add(5, 'مديونية منخفضة (دين/ملكية ${fmtNum(de, 1)})');
    } else if (de > 2) {
      sc.sub(5, 'مديونية عالية (دين/ملكية ${fmtNum(de, 1)})');
    }
  }
  final g = f.revenueGrowthPct;
  if (g != null && g >= 10) sc.add(5, 'نمو إيرادات ${fmtNum(g, 1)}%');
}

// ───────────── دخول / وقف / أهداف ─────────────

Pick _buildTrade(_Stat s) {
  final price = s.last, atr = s.atrV;
  var stop = price - 1.5 * atr;
  final sup = s.levels.support.isEmpty ? null : s.levels.support.first;
  if (sup != null) {
    final d = price - sup;
    if (d >= atr && d <= 2.5 * atr) stop = sup - 0.25 * atr;
  }
  if (stop <= 0) stop = price * 0.95;
  final risk = price - stop;
  final res = s.levels.resistance.isEmpty ? null : s.levels.resistance.first;
  final t1 = (res != null && res - price >= risk) ? res : price + 1.5 * risk;
  final t2 = math.max(price + 3 * risk, t1 + risk);
  final hi = s.hi20;
  final note = (hi != null && price < hi)
      ? 'ادخل قرب ${fmtNum(price)} أو عند كسر ${fmtNum(hi)} بحجم تداول أعلى من المتوسط.'
      : 'السهم عند قمة 20 يوم. الأفضل تستنى ارتداد بسيط لحد ${fmtNum(price - 0.5 * atr)} بدل مطاردة السعر.';
  return Pick(
    quote: s.quote,
    mode: PickMode.trade,
    score: s.trade.pts.clamp(0, 100).toInt(),
    reasons: s.trade.reasons,
    warnings: s.trade.warnings,
    price: price,
    entryLow: price - 0.3 * atr,
    entryHigh: price + 0.3 * atr,
    stop: stop,
    target1: t1,
    target2: t2,
    entryNote: note,
    horizon: 'مدة مقترحة: من جلسة لحوالي 5 جلسات. اخرج لو اتكسر الوقف.',
    asOf: s.asOf,
  );
}

Pick _buildInvest(_Stat s) {
  final price = s.last, atr = s.atrV;
  var stop = price - 4 * atr;
  final s200 = s.s200;
  if (s200 != null && s200 < price) stop = math.max(stop, s200 * 0.98);
  stop = math.min(stop, price - 2 * atr);
  if (stop <= 0) stop = price * 0.85;
  final risk = price - stop;
  final res = s.levels.resistance.isEmpty ? null : s.levels.resistance.first;
  final t1 = (res != null && res - price >= 1.5 * risk) ? res : price + 2 * risk;
  var t2 = price + 3 * risk;
  if (s.yearHigh > t1) t2 = math.max(s.yearHigh, t2);
  t2 = math.max(t2, t1 + risk);
  final s50 = s.s50;
  final low = (s50 != null && s50 < price && price - s50 < 0.1 * price) ? s50 : price - atr;
  return Pick(
    quote: s.quote,
    mode: PickMode.invest,
    score: s.invest.pts.clamp(0, 100).toInt(),
    reasons: s.invest.reasons,
    warnings: s.invest.warnings,
    price: price,
    entryLow: low,
    entryHigh: price,
    stop: stop,
    target1: t1,
    target2: t2,
    entryNote:
        'ادخل على دفعتين: نص الكمية قرب ${fmtNum(price)} ونصها عند ارتداد لحد ${fmtNum(low)}.',
    horizon: 'مدة مقترحة: أسابيع إلى شهور. راجع السهم لو اتكسر الوقف.',
    asOf: s.asOf,
    hasFundamentals: s.hasFund,
  );
}

// ───────────── التشغيل ─────────────

Future<List<R?>> _pool<T, R>(
  List<T> items,
  int limit,
  Future<R?> Function(T) fn,
  void Function() tick,
) async {
  final out = List<R?>.filled(items.length, null);
  var next = 0;
  Future<void> worker() async {
    while (true) {
      final i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i]);
      tick();
    }
  }

  await Future.wait([for (var k = 0; k < limit; k++) worker()]);
  return out;
}

/// بيفحص كل الأسهم في [quotes] (لازم تكون بيانات حقيقية مش تجريبية).
Future<ScanResult> runScan(
  MarketDataSource source,
  List<Quote> quotes, {
  void Function(String stage, int done, int total)? onProgress,
}) async {
  var done = 0;
  final total = quotes.length;
  onProgress?.call('جاري تحميل الأسعار التاريخية', 0, total);

  final stats = await _pool<Quote, _Stat>(quotes, 4, (q) async {
    try {
      final c = await source.fetchHistory(q.symbol, days: 260);
      return c.length < 60 ? null : _Stat(q, c);
    } catch (_) {
      return null;
    }
  }, () {
    done++;
    onProgress?.call('جاري تحميل الأسعار التاريخية', done, total);
  });

  final valid = stats.whereType<_Stat>().toList();
  for (final s in valid) {
    s.trade = _tradeScore(s);
    s.invest = _investScore(s);
  }

  // البيانات المالية بس لأقوى المرشحين للاستثمار (علشان نقلل الطلبات).
  final cand = ([...valid]..sort((a, b) => b.invest.pts.compareTo(a.invest.pts)))
      .where((s) => s.s200 != null)
      .take(8)
      .toList();
  onProgress?.call('جاري جلب البيانات المالية', 0, cand.length);
  var fdone = 0;
  final funds = await _pool<_Stat, Fundamentals>(cand, 3, (s) async {
    try {
      return await source.fetchFundamentals(s.quote.symbol);
    } catch (_) {
      return null;
    }
  }, () {
    fdone++;
    onProgress?.call('جاري جلب البيانات المالية', fdone, cand.length);
  });
  for (var i = 0; i < cand.length; i++) {
    final f = funds[i];
    if (f != null) {
      _fundScore(cand[i].invest, cand[i].last, f);
      cand[i].hasFund = true;
    }
  }

  final tradeList = valid
      .where((s) => s.trade.pts >= 55 && (s.liq?.avgValue20 ?? 0) >= 1e6)
      .toList()
    ..sort((a, b) => b.trade.pts.compareTo(a.trade.pts));
  final investList = valid.where((s) => s.s200 != null && s.invest.pts >= 55).toList()
    ..sort((a, b) => b.invest.pts.compareTo(a.invest.pts));

  DateTime? session;
  for (final s in valid) {
    if (session == null || s.asOf.isAfter(session)) session = s.asOf;
  }

  return ScanResult(
    trade: tradeList.take(5).map(_buildTrade).toList(),
    invest: investList.take(5).map(_buildInvest).toList(),
    scanned: valid.length,
    failed: quotes.length - valid.length,
    time: DateTime.now(),
    sessionDate: session,
  );
}
