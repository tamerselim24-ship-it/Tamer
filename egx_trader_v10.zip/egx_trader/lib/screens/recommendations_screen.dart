import 'package:flutter/material.dart';

import '../analysis/screener.dart';
import '../models.dart';
import '../state.dart';
import '../util.dart';
import 'settings_screen.dart';

/// شاشة الترشيحات: فحص الأسهم، قايمة مضاربة وقايمة استثمار، وشرح بالـ AI.
class RecommendationsView extends StatefulWidget {
  const RecommendationsView({super.key, required this.state, required this.onTap});
  final AppState state;
  final void Function(Quote) onTap;

  @override
  State<RecommendationsView> createState() => _RecommendationsViewState();
}

class _RecommendationsViewState extends State<RecommendationsView> {
  PickMode _mode = PickMode.trade;

  String _d(DateTime d) =>
      '${d.day.toString().padLeft(2, "0")}/${d.month.toString().padLeft(2, "0")}';

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    final r = s.scan;
    final picks = r == null ? const <Pick>[] : (_mode == PickMode.trade ? r.trade : r.invest);

    return ListView(padding: const EdgeInsets.all(12), children: [
      if (s.isDemo)
        const Card(
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Text('البيانات الحالية تجريبية، فالفحص متوقف. الترشيحات لازم تتبني على بيانات حقيقية.'),
          ),
        ),
      FilledButton.icon(
        onPressed: (s.scanning || s.isDemo || s.quotes.isEmpty) ? null : s.runPicksScan,
        icon: const Icon(Icons.search),
        label: Text(r == null ? 'ابدأ فحص الأسهم' : 'افحص من جديد'),
      ),
      if (s.scanning) ...[
        const SizedBox(height: 12),
        LinearProgressIndicator(
          value: s.scanTotal == 0 ? null : s.scanDone / s.scanTotal,
        ),
        const SizedBox(height: 4),
        Text('${s.scanStage} (${s.scanDone}/${s.scanTotal})',
            style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
      if (s.scanError != null) ...[
        const SizedBox(height: 12),
        Text(s.scanError!, style: const TextStyle(color: Colors.redAccent)),
      ],
      if (r == null && !s.scanning && s.scanError == null)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text(
            'الفحص بيحمّل تاريخ أعلى $kScanLimit سهم سيولة (وأسهم المراقبة) وممكن ياخد دقيقة أو اتنين. '
            'وبيرتّبها بنقاط حسب الزخم والاتجاه والسيولة، وبيحسب لكل سهم دخول ووقف وأهداف.',
            style: TextStyle(color: Colors.grey),
          ),
        ),
      if (r != null) ...[
        const SizedBox(height: 12),
        Text(
          'اتفحص ${r.scanned} سهم'
          '${r.failed > 0 ? " (تعذّر ${r.failed})" : ""}'
          '${r.sessionDate == null ? "" : " • بيانات جلسة ${_d(r.sessionDate!)} من ياهو"}',
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 8),
        SegmentedButton<PickMode>(
          segments: [
            ButtonSegment(value: PickMode.trade, label: Text('مضاربة (${r.trade.length})')),
            ButtonSegment(value: PickMode.invest, label: Text('استثمار (${r.invest.length})')),
          ],
          selected: {_mode},
          onSelectionChanged: (v) => setState(() => _mode = v.first),
        ),
        const SizedBox(height: 12),
        if (picks.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'مفيش أسهم استوفت الشروط في القايمة دي. ده ممكن يبقى طبيعي: أحيانًا مفيش فرص واضحة. '
                'حط أسهمك في المراقبة (النجمة) لو عايز تضمّنها في الفحص.',
              ),
            ),
          ),
        for (final p in picks) _pickCard(p),
        if (r.trade.isNotEmpty || r.invest.isNotEmpty) _aiSection(s),
      ],
      const _Note(),
    ]);
  }

  Widget _aiSection(AppState s) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      OutlinedButton.icon(
        onPressed: s.picksAiBusy ? null : s.explainPicks,
        icon: const Icon(Icons.auto_awesome),
        label: Text(s.picksAi == null
            ? 'اشرح الترشيحات بالذكاء الاصطناعي'
            : 'اشرح من جديد'),
      ),
      if (s.picksAiBusy)
        const Padding(
          padding: EdgeInsets.only(top: 12),
          child: LinearProgressIndicator(),
        ),
      if (s.picksAiError != null) ...[
        const SizedBox(height: 8),
        Text(s.picksAiError!, style: const TextStyle(color: Colors.redAccent)),
        if (s.picksAiNeedsKey)
          TextButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
            ),
            icon: const Icon(Icons.settings),
            label: const Text('افتح الإعدادات'),
          ),
      ],
      if (s.picksAi != null) ...[
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: SelectableText(s.picksAi!, style: const TextStyle(height: 1.6)),
          ),
        ),
      ],
    ]);
  }

  Widget _row(String k, String v, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: const TextStyle(color: Colors.grey, fontSize: 13)),
          Text(v, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
        ]),
      );

  Widget _pickCard(Pick p) {
    final q = p.quote;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => widget.onTap(q),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text('${q.symbol} • ${q.name}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0x4026A69A),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('${p.score}/100',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ]),
            const SizedBox(height: 4),
            Text(
              'إغلاق ${fmtNum(p.price)} (${fmtPct(q.changePct)}) • جلسة ${_d(p.asOf)}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const Divider(),
            _row('منطقة الدخول', '${fmtNum(p.entryLow)} – ${fmtNum(p.entryHigh)}'),
            _row('وقف الخسارة', '${fmtNum(p.stop)}  (${fmtPct(-p.riskPct)})',
                color: Colors.redAccent),
            _row('الهدف الأول', '${fmtNum(p.target1)}  (${fmtPct(p.gain1Pct)})',
                color: Colors.green),
            _row('الهدف الثاني', '${fmtNum(p.target2)}  (${fmtPct(p.gain2Pct)})',
                color: Colors.green),
            _row('العائد ÷ المخاطرة', '1 : ${fmtNum(p.rewardRisk, 1)}'),
            const SizedBox(height: 8),
            Text(p.entryNote, style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 2),
            Text(p.horizon, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            if (p.mode == PickMode.invest && !p.hasFundamentals)
              const Text('بدون بيانات مالية (مش متاحة لهذا السهم)',
                  style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 8),
            for (final x in p.reasons)
              Text('✓ $x', style: const TextStyle(fontSize: 12, color: Colors.green)),
            for (final w in p.warnings)
              Text('! $w', style: const TextStyle(fontSize: 12, color: Colors.orange)),
          ]),
        ),
      ),
    );
  }
}

class _Note extends StatelessWidget {
  const _Note();

  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          'الترشيحات نتيجة قواعد حسابية عامة، ومتجرّبتش على بيانات تاريخية، وبتتبني على أسعار '
          'ياهو اللي ممكن تتأخر يوم. اتأكد من السعر الحالي في تبويب "مباشر" قبل أي قرار. '
          'دي أفكار للدراسة وليست توصية استثمارية، والمستويات تقريبية وبتتغير مع السوق.',
          style: TextStyle(fontSize: 11, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
      );
}
