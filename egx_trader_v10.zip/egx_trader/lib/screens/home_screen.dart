import 'package:flutter/material.dart';

import '../data/egx_universe.dart';
import '../models.dart';
import '../state.dart';
import '../util.dart';
import '../widgets/live_market.dart';
import 'liquidity_screen.dart';
import 'recommendations_screen.dart';
import 'settings_screen.dart';
import 'stock_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.state});
  final AppState state;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  String _query = '';
  bool _grouped = true;

  static const _titles = ['الأسهم', 'قائمة المراقبة', 'السيولة', 'السوق المباشر', 'الترشيحات'];

  void _open(Quote q) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => StockScreen(quote: q, source: widget.state.source),
    ));
  }

  String _statusLine(AppState s) {
    String two(int n) => n.toString().padLeft(2, '0');
    final u = s.updatedAt!;
    final d = s.dataDate;
    final upd = '${two(u.hour)}:${two(u.minute)}';
    final session = d == null ? '' : ' • آخر جلسة تداول ${two(d.day)}/${two(d.month)}';
    return 'آخر تحديث $upd$session • $kAppVersion';
  }

  Future<void> _addDialog() async {
    final ctrl = TextEditingController();
    String? error;
    var busy = false;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('إضافة سهم'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: ctrl,
              autofocus: true,
              textDirection: TextDirection.ltr,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                hintText: 'رمز السهم، مثال: CIEB',
                errorText: error,
              ),
            ),
            if (busy)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: LinearProgressIndicator(),
              ),
          ]),
          actions: [
            TextButton(
              onPressed: busy ? null : () => Navigator.pop(ctx),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      setD(() {
                        busy = true;
                        error = null;
                      });
                      final err = await widget.state.addSymbol(ctrl.text);
                      if (err == null) {
                        if (ctx.mounted) Navigator.pop(ctx);
                      } else {
                        setD(() {
                          busy = false;
                          error = err;
                        });
                      }
                    },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
    ctrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.state,
      builder: (context, _) {
        final s = widget.state;
        return Scaffold(
          appBar: AppBar(
            title: Text(_titles[_tab]),
            actions: [
              IconButton(
                icon: const Icon(Icons.add),
                tooltip: 'إضافة سهم',
                onPressed: _addDialog,
              ),
              IconButton(
                icon: const Icon(Icons.settings),
                tooltip: 'الإعدادات',
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
                ),
              ),
              IconButton(
                icon: s.loading
                    ? const SizedBox(
                        width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.refresh),
                onPressed: s.loading ? null : s.refresh,
              ),
            ],
          ),
          body: Column(children: [
            if (s.isDemo)
              Container(
                width: double.infinity,
                color: Colors.amber.shade900,
                padding: const EdgeInsets.all(6),
                child: Text(
                  'بيانات تجريبية — فشل الجلب من المصدر: ${s.sourceError ?? ""}',
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            if (s.error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(s.error!, style: const TextStyle(color: Colors.redAccent)),
              ),
            if (s.loading && s.loadTotal > 0 && s.loadDone < s.loadTotal)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  LinearProgressIndicator(value: s.loadDone / s.loadTotal),
                  const SizedBox(height: 2),
                  Text('بيتحمّل ${s.loadDone} من ${s.loadTotal} سهم…',
                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                ]),
              ),
            if (s.staleMessage != null && _tab != 3)
              Container(
                width: double.infinity,
                color: Colors.orange.shade900,
                padding: const EdgeInsets.all(6),
                child: Text(
                  s.staleMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            if (s.updatedAt != null && _tab != 3)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(_statusLine(s),
                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ),
            Expanded(child: _body(s)),
          ]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.show_chart), label: 'الأسهم'),
              NavigationDestination(icon: Icon(Icons.star), label: 'المراقبة'),
              NavigationDestination(icon: Icon(Icons.water_drop), label: 'السيولة'),
              NavigationDestination(icon: Icon(Icons.bolt), label: 'مباشر'),
              NavigationDestination(icon: Icon(Icons.thumb_up), label: 'ترشيحات'),
            ],
          ),
        );
      },
    );
  }

  Widget _body(AppState s) {
    if (_tab == 3) return const LiveMarketView();
    if (_tab == 4) return RecommendationsView(state: s, onTap: _open);
    if (s.quotes.isEmpty) {
      return Center(child: s.loading ? const CircularProgressIndicator() : const Text('لا توجد بيانات'));
    }
    switch (_tab) {
      case 1:
        final list = s.quotes.where((q) => s.watchlist.contains(q.symbol)).toList();
        if (list.isEmpty) {
          return const Center(child: Text('ضيف أسهم بالضغط على النجمة'));
        }
        return _list(s, list);
      case 2:
        return LiquidityView(quotes: s.quotes, onTap: _open);
      default:
        final q = _query.trim().toLowerCase();
        final list = q.isEmpty
            ? s.quotes
            : s.quotes
                .where((x) => x.symbol.toLowerCase().contains(q) || x.name.contains(q))
                .toList();
        final searching = q.isNotEmpty;
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'ابحث بالرمز أو الاسم',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: _grouped ? 'عرض كقايمة واحدة' : 'تقسيم حسب القطاع',
                icon: Icon(_grouped ? Icons.view_list : Icons.category),
                onPressed: () => setState(() => _grouped = !_grouped),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Text('${list.length} سهم', style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ),
          Expanded(
            child: (_grouped && !searching)
                ? _sectors(s, list)
                : _list(s, [...list]..sort((a, b) => b.value.compareTo(a.value))),
          ),
        ]);
    }
  }

  /// الأسهم متقسّمة على قطاعات، كل قطاع قابل للفتح والقفل.
  Widget _sectors(AppState s, List<Quote> list) {
    final groups = <String, List<Quote>>{};
    for (final q in list) {
      final sec = kEgxIndex.containsKey(q.symbol)
          ? sectorOf(q.symbol)
          : (q.sector.isNotEmpty ? q.sector : kOtherSector);
      groups.putIfAbsent(sec, () => []).add(q);
    }
    final order = <String>[
      ...kSectorOrder.where(groups.containsKey),
      ...groups.keys.where((k) => !kSectorOrder.contains(k)),
    ];
    return RefreshIndicator(
      onRefresh: s.refresh,
      child: ListView(
        children: [
          for (final sec in order) _sectorTile(s, sec, groups[sec]!),
        ],
      ),
    );
  }

  Widget _sectorTile(AppState s, String sec, List<Quote> items) {
    final sorted = [...items]..sort((a, b) => b.value.compareTo(a.value));
    final avg = items.fold<double>(0, (t, q) => t + q.changePct) / items.length;
    return ExpansionTile(
      key: PageStorageKey<String>('sector_$sec'),
      title: Text(sec, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${items.length} سهم • متوسط التغيّر ${fmtPct(avg)}',
          style: TextStyle(fontSize: 12, color: changeColor(avg))),
      children: [for (final q in sorted) _tile(s, q)],
    );
  }

  Widget _list(AppState s, List<Quote> list) {
    return RefreshIndicator(
      onRefresh: s.refresh,
      child: ListView.separated(
        itemCount: list.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          return _tile(s, list[i]);
        },
      ),
    );
  }

  Widget _tile(AppState s, Quote q) {
    final color = changeColor(q.change);
    final watched = s.watchlist.contains(q.symbol);
    return ListTile(
      onTap: () => _open(q),
      onLongPress: s.isExtra(q.symbol)
          ? () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text('حذف ${q.symbol}؟'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('إلغاء')),
                    FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('حذف')),
                  ],
                ),
              );
              if (ok == true) s.removeSymbol(q.symbol);
            }
          : null,
      leading: IconButton(
        icon: Icon(watched ? Icons.star : Icons.star_border,
            color: watched ? Colors.amber : null),
        onPressed: () => s.toggleWatch(q.symbol),
      ),
      title: Text(q.symbol, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${q.name} • حجم ${fmtCompact(q.volume)}'),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(fmtNum(q.last), style: const TextStyle(fontSize: 16)),
          Text(fmtPct(q.changePct), style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }
}
