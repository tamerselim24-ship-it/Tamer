import 'package:flutter/material.dart';

import '../ai/ai_service.dart';
import '../util.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _ctrl = TextEditingController();
  String _model = AiService.defaultModel;
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final k = await AiService.getKey();
    final m = await AiService.getModel();
    if (!mounted) return;
    setState(() {
      _ctrl.text = k ?? '';
      _model = m;
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await AiService.setKey(_ctrl.text);
    await AiService.setModel(_model);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('التحليل بالذكاء الاصطناعي',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          controller: _ctrl,
          obscureText: _hide,
          textDirection: TextDirection.ltr,
          autocorrect: false,
          enableSuggestions: false,
          decoration: InputDecoration(
            labelText: 'مفتاح Anthropic API',
            hintText: 'sk-ant-...',
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(
              icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
              onPressed: () => setState(() => _hide = !_hide),
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('الموديل'),
        DropdownButton<String>(
          isExpanded: true,
          value: _model,
          items: [
            for (final e in AiService.models.entries)
              DropdownMenuItem(value: e.key, child: Text(e.value)),
          ],
          onChanged: (v) => setState(() => _model = v ?? _model),
        ),
        const SizedBox(height: 16),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
        const SizedBox(height: 24),
        const Text(
          'خد المفتاح من console.anthropic.com (قسم API Keys). حساب الـ API منفصل '
          'عن اشتراك تطبيق Claude، وبيتحاسب على قد الاستخدام.\n\n'
          'المفتاح بيتحفظ على موبايلك بس، ومش بيتبعت لأي مكان غير Anthropic.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 24),
        const Text('إصدار التطبيق: $kAppVersion',
            style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    );
  }
}
