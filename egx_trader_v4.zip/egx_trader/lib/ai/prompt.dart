import '../analysis/fundamental.dart';
import '../analysis/liquidity.dart';
import '../analysis/technical.dart';
import '../models.dart';
import '../util.dart';

const aiSystemPrompt = '''
أنت محلل أسواق مالية متخصص في البورصة المصرية (EGX). هتستلم بيانات سهم واحد (أسعار، مؤشرات فنية، سيولة، نسب مالية) محسوبة بالفعل. حلّلها بدقة وبعربي واضح ومبسّط (ممكن عامية مصرية خفيفة).

التزم بالآتي:
- اعتمد فقط على الأرقام المرفقة، ولا تخترع أرقام أو أخبار أو أحداث غير موجودة.
- لو بيانات ناقصة أو غير متاحة، قول كده صراحة.
- اكتب بنص عادي بدون Markdown (لا تستخدم # ولا ** ولا جداول). العنوان يكون سطر لوحده، والنقاط تبدأ بشرطة (-).
- مفيش توصية شراء أو بيع قاطعة. اعرض سيناريوهات ومستويات ومخاطر.
- اختم بسطر تنبيه إن ده تحليل آلي وليس نصيحة استثمارية.
''';

String _n(double? v, [int d = 2]) => v == null ? 'غير متاح' : fmtNum(v, d);

String _date(DateTime d) => d.toIso8601String().substring(0, 10);

String _chg(List<double> c, int n) {
  if (c.length <= n) return 'غير متاح';
  final base = c[c.length - 1 - n];
  if (base == 0) return 'غير متاح';
  return fmtPct((c.last / base - 1) * 100);
}

String _verdictAr(Verdict v) => switch (v) {
      Verdict.buy => 'إيجابي',
      Verdict.sell => 'سلبي',
      Verdict.neutral => 'محايد',
    };

String buildAnalysisPrompt({
  required Quote quote,
  required List<Candle> candles,
  Fundamentals? fundamentals,
  required bool isDemo,
}) {
  final out = StringBuffer();
  void line(String s) => out.writeln(s);

  line('السهم: ${quote.symbol} - ${quote.name}');
  if (isDemo) {
    line('تنبيه: البيانات دي تجريبية مش حقيقية، اذكر ده في أول التحليل.');
  }
  line('');
  line('== السعر ==');
  line('آخر سعر: ${fmtNum(quote.last)} جنيه');
  line('التغير عن الإغلاق السابق: ${fmtNum(quote.change)} (${fmtPct(quote.changePct)})');
  line('الافتتاح ${fmtNum(quote.open)} | الأعلى ${fmtNum(quote.high)} | '
      'الأدنى ${fmtNum(quote.low)} | الإغلاق السابق ${fmtNum(quote.prevClose)}');
  line('حجم التداول: ${fmtCompact(quote.volume)} سهم | '
      'قيمة التداول: ${fmtCompact(quote.value)} جنيه');

  if (candles.isNotEmpty) {
    final closes = [for (final c in candles) c.close];
    var hi = candles.first.high, lo = candles.first.low;
    for (final c in candles) {
      if (c.high > hi) hi = c.high;
      if (c.low < lo) lo = c.low;
    }
    line('');
    line('== الأداء التاريخي (${candles.length} جلسة من '
        '${_date(candles.first.date)} إلى ${_date(candles.last.date)}) ==');
    line('أعلى سعر في الفترة: ${fmtNum(hi)} | أدنى سعر: ${fmtNum(lo)}');
    line('التغير: شهر ${_chg(closes, 21)} | 3 شهور ${_chg(closes, 63)} | '
        '6 شهور ${_chg(closes, 126)} | سنة ${_chg(closes, 252)}');

    final summary = analyzeTechnical(candles);
    if (summary.signals.isNotEmpty) {
      final m = macd(closes);
      final bb = bollinger(closes);
      final lv = pivotLevels(candles);
      line('');
      line('== التحليل الفني ==');
      line('SMA20=${_n(sma(closes, 20).last)} | SMA50=${_n(sma(closes, 50).last)} | '
          'SMA200=${_n(sma(closes, 200).last)}');
      line('RSI(14)=${_n(rsi(closes).last, 1)}');
      line('MACD=${_n(m.line.last, 3)} | Signal=${_n(m.signal.last, 3)} | '
          'Histogram=${_n(m.hist.last, 3)}');
      line('بولينجر: علوي=${_n(bb.upper.last)} | وسط=${_n(bb.mid.last)} | '
          'سفلي=${_n(bb.lower.last)}');
      line('مقاومة: ${lv.resistance.isEmpty ? "غير محددة" : lv.resistance.map(fmtNum).join(" / ")}');
      line('دعم: ${lv.support.isEmpty ? "غير محدد" : lv.support.map(fmtNum).join(" / ")}');
      line('الإشارات: إيجابية ${summary.buy} | سلبية ${summary.sell} | '
          'محايدة ${summary.neutral} => ${summary.overall}');
      for (final s in summary.signals) {
        line('- ${s.name}: ${_verdictAr(s.verdict)} (${s.detail})');
      }
    }

    final liq = analyzeLiquidity(candles);
    if (liq != null) {
      line('');
      line('== السيولة ==');
      line('متوسط الحجم 20 يوم: ${fmtCompact(liq.avgVolume20)} سهم | '
          'متوسط قيمة التداول: ${fmtCompact(liq.avgValue20)} جنيه');
      line('حجم آخر جلسة ÷ المتوسط = ${fmtNum(liq.volumeRatio)}x (${liq.activity})');
      line('OBV: ${liq.obvRising ? "صاعد (تجميع)" : "هابط (تصريف)"} | '
          'MFI(14)=${_n(liq.mfi, 1)}');
    }
  } else {
    line('');
    line('السجل التاريخي غير متاح، فمفيش تحليل فني أو سيولة تاريخية.');
  }

  line('');
  line('== التحليل المالي ==');
  final f = fundamentals;
  if (f == null) {
    line('البيانات المالية غير متاحة لهذا السهم.');
  } else {
    if (f.revenue != null) line('الإيرادات: ${fmtCompact(f.revenue!)}');
    if (f.netProfit != null) line('صافي الربح: ${fmtCompact(f.netProfit!)}');
    if (f.eps != null) line('ربحية السهم EPS: ${fmtNum(f.eps!)}');
    for (final r in analyzeFundamentals(quote, f)) {
      line('- ${r.name}: ${r.value}${r.note.isEmpty ? "" : " (${r.note})"}');
    }
  }

  line('');
  line('المطلوب تحليل منظم بالترتيب ده، كل قسم بعنوان في سطر لوحده:');
  line('الملخص (سطرين)');
  line('الصورة الفنية');
  line('السيولة والحجم');
  line('الصورة المالية');
  line('سيناريو صعودي وسيناريو هبوطي (بمستويات من البيانات المرفقة فقط)');
  line('المخاطر ونقاط المتابعة');
  line('الخلاصة');
  return out.toString();
}
