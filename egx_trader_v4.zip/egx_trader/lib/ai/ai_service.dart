import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'prompt.dart';

class AiException implements Exception {
  const AiException(this.message, {this.needsKey = false});
  final String message;

  /// true لو المشكلة في المفتاح (مفقود أو غلط) فنعرض زرار الإعدادات.
  final bool needsKey;

  @override
  String toString() => message;
}

/// نداء مباشر لـ Claude API من الموبايل بمفتاح المستخدم نفسه.
/// المفتاح بيتحفظ على الجهاز بس، ومش متضمّن في الـ APK.
class AiService {
  static const _keyPref = 'anthropic_api_key';
  static const _modelPref = 'ai_model';
  static const defaultModel = 'claude-sonnet-5-5';

  static const models = <String, String>{
    'claude-sonnet-5-5': 'Sonnet 5.5 (متوازن)',
    'claude-haiku-5-5': 'Haiku 5.5 (أسرع وأرخص)',
    'claude-opus-5-5': 'Opus 5.5 (الأقوى)',
  };

  static Future<String?> getKey() async {
    try {
      final p = await SharedPreferences.getInstance();
      final k = p.getString(_keyPref);
      return (k == null || k.trim().isEmpty) ? null : k.trim();
    } catch (_) {
      return null;
    }
  }

  static Future<void> setKey(String key) async {
    final p = await SharedPreferences.getInstance();
    if (key.trim().isEmpty) {
      await p.remove(_keyPref);
    } else {
      await p.setString(_keyPref, key.trim());
    }
  }

  static Future<String> getModel() async {
    try {
      final p = await SharedPreferences.getInstance();
      final m = p.getString(_modelPref);
      return (m != null && models.containsKey(m)) ? m : defaultModel;
    } catch (_) {
      return defaultModel;
    }
  }

  static Future<void> setModel(String model) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_modelPref, model);
  }

  static Future<String> analyze(String prompt) async {
    final key = await getKey();
    if (key == null) {
      throw const AiException(
        'محتاج مفتاح Anthropic API الأول. افتح الإعدادات وحطه.',
        needsKey: true,
      );
    }
    final model = await getModel();

    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('https://api.anthropic.com/v1/messages'),
            headers: {
              'x-api-key': key,
              'anthropic-version': '2023-06-01',
              'content-type': 'application/json',
            },
            body: jsonEncode({
              'model': model,
              'max_tokens': 2000,
              'system': aiSystemPrompt,
              'messages': [
                {'role': 'user', 'content': prompt},
              ],
            }),
          )
          .timeout(const Duration(seconds: 90));
    } catch (e) {
      throw AiException('تعذّر الاتصال بخدمة الذكاء الاصطناعي. اتأكد من الإنترنت. ($e)');
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw AiException('رد غير مفهوم من الخدمة (HTTP ${res.statusCode})');
    }

    if (res.statusCode != 200) {
      final msg = (data['error'] as Map?)?['message'] ?? 'HTTP ${res.statusCode}';
      if (res.statusCode == 401 || res.statusCode == 403) {
        throw AiException('المفتاح مرفوض: $msg', needsKey: true);
      }
      throw AiException('خطأ من الخدمة (${res.statusCode}): $msg');
    }

    final parts = (data['content'] as List?) ?? const [];
    final text = parts
        .whereType<Map>()
        .where((p) => p['type'] == 'text')
        .map((p) => '${p['text']}')
        .join('\n')
        .trim();
    if (text.isEmpty) throw const AiException('الخدمة رجّعت رد فاضي، جرّب تاني.');
    return text;
  }
}
