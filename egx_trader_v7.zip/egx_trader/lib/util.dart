import 'package:flutter/material.dart';

/// رقم الإصدار، بيظهر في الإعدادات وتحت قايمة الأسهم علشان تعرف النسخة المركّبة.
const kAppVersion = 'v7';

String fmtNum(double v, [int d = 2]) => v.toStringAsFixed(d);

String fmtCompact(double v) {
  final a = v.abs();
  if (a >= 1e9) return '${(v / 1e9).toStringAsFixed(2)} مليار';
  if (a >= 1e6) return '${(v / 1e6).toStringAsFixed(2)} مليون';
  if (a >= 1e3) return '${(v / 1e3).toStringAsFixed(1)} ألف';
  return v.toStringAsFixed(0);
}

// ‎ = علامة اتجاه يسار→يمين، عشان الإشارة و% ما ينعكسوش في الواجهة العربية.
String fmtPct(double v) => '‎${v > 0 ? '+' : ''}${v.toStringAsFixed(2)}%';

Color changeColor(double x) => x > 0
    ? Colors.green
    : x < 0
        ? Colors.red
        : Colors.grey;

/// يحوّل الأرقام العربية-الهندية وفواصل الآلاف إلى double.
double? parseNum(String? raw) {
  if (raw == null) return null;
  var s = raw.trim();
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < arabic.length; i++) {
    s = s.replaceAll(arabic[i], '$i');
  }
  s = s
      .replaceAll('٬', '')
      .replaceAll(',', '')
      .replaceAll('٫', '.')
      .replaceAll('%', '')
      .replaceAll(RegExp(r'\s'), '');
  if (s.isEmpty || s == '-') return null;
  var mult = 1.0;
  final last = s[s.length - 1].toUpperCase();
  if (last == 'K') {
    mult = 1e3;
    s = s.substring(0, s.length - 1);
  } else if (last == 'M') {
    mult = 1e6;
    s = s.substring(0, s.length - 1);
  } else if (last == 'B') {
    mult = 1e9;
    s = s.substring(0, s.length - 1);
  }
  final v = double.tryParse(s);
  return v == null ? null : v * mult;
}
