import 'package:flutter/material.dart';

import '../models.dart';
import '../util.dart';

/// أسهم عليها نشاط تداول غير عادي (حجم أعلى بكتير من المتوسط).
///
/// مهم: ياهو مبيدّيش صفقات فردية ولا صفقات "الأوامر الكبيرة". فالتبويب ده
/// بيكشف الأسهم اللي حجمها اليوم أعلى من متوسط آخر 20 جلسة، وده مؤشر
/// على دخول سيولة كبيرة، مش دليل على صفقة بعينها.
class BigDealsView extends StatefulWidget {
  const BigDealsView({super.key, required this.quotes, required this.onTap});
  final List<Quote> quotes;
  final void Function(Quote) onTap;

  @override
  State<BigDealsView> createState() => _BigDealsViewState();
}

class _BigDealsViewState extends State<BigDealsView> {
  double _minRatio = 2;
  double _minValue = 1e6;

  static const _ratios = [2.0, 3.0, 5.0];
  static const _values = [1e6, 5e6, 20e6];

  /// موقع الإغلاق جوه مدى اليوم: 0 = القاع، 1 = القمة.
  double? _closePos(Quote q) {
    final r = q.high - q.low;
    return r <= 0 ? null : (q.last - q.low) / r;
  }

  String _read(Quote q) {
    final pos = _closePos(q);
    final up = q.changePct;
    if (pos == null) return 'حجم عالي بدون حركة سعر تُذكر';
    if (up > 0.5 && pos >= 0.7) return 'حجم عالي مع إغلاق قرب القمة (ضغط شراء محتمل)';
    if (up < -0.5 && pos <= 0.3) return 'حجم عالي مع إغلاق قرب القاع (ضغط بيع محتمل)';
    return 'حجم عالي والسعر متذبذب (اتجاه غير واضح)';
  }

  @override
  Widget build(BuildContext context) {
    final withAvg = widget.quotes.where((q) => q.volumeRatio != null).toList();
    final hits = withAvg
        .where((q) => q.volumeRatio! >= _minRatio && q.value >= _minValue)
        .toList()
      ..sort((a, b) => b.volumeRatio!.compareTo(a.volumeRatio!));

    return ListView(padding: const EdgeInsets.all(12), children: [
      const Card(
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Text(
            'ياهو مبيدّيش صفقات فردية، فمقدرش أعرض "صفقة كبيرة" بعينها. '
            'التبويب ده بيعرض الأسهم اللي حجم تداولها آخر جلسة أعلى من متوسط 20 جلسة، '
            'وده مؤشر على دخول سيولة كبيرة (مؤسسات أو أفراد كبار) مش أكتر.',
            style: TextStyle(fontSize: 12, height: 1.5),
          ),
        ),
      ),
      const SizedBox(height: 12),
      const Text('الحجم مقارنة بالمتوسط', style: TextStyle(fontSize: 12, color: Colors.grey)),
      Wrap(spacing: 8, children: [
        for (final r in _ratios)
          ChoiceChip(
            label: Text('${r.toStringAsFixed(0)}× فأكثر'),
            selected: _minRatio == r,
            onSelected: (_) => setState(() => _minRatio = r),
          ),
      ]),
      const SizedBox(height: 8),
      const Text('أقل قيمة تداول', style: TextStyle(fontSize: 12, color: Colors.grey)),
      Wrap(spacing: 8, children: [
        for (final v in _values)
          ChoiceChip(
            label: Text('${fmtCompact(v)} ج.م'),
            selected: _minValue == v,
            onSelected: (_) => setState(() => _minValue = v),
          ),
      ]),
      const SizedBox(height: 12),
      if (withAvg.isEmpty)
        const Text('مفيش بيانات متوسط حجم متاحة (المصدر الحالي تجريبي أو لسه بيحمّل).',
            style: TextStyle(color: Colors.grey))
      else if (hits.isEmpty)
        const Text('مفيش أسهم بنشاط غير عادي بالفلاتر دي. جرّب تخفّف الفلاتر.',
            style: TextStyle(color: Colors.grey))
      else
        Text('${hits.length} سهم', style: const TextStyle(fontSize: 12, color: Colors.grey)),
      for (final q in hits) _card(q),
      const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text(
          'أثناء الجلسة حجم اليوم لسه ناقص فالنسبة بتبان أقل من الحقيقة. ارتفاع الحجم مش بيضمن اتجاه السعر، '
          'وفكرة للدراسة وليست توصية.',
          style: TextStyle(fontSize: 11, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
      ),
    ]);
  }

  Widget _card(Quote q) {
    final ratio = q.volumeRatio!;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: () => widget.onTap(q),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text('${q.symbol} • ${q.name}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0x40FFB300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('×${ratio.toStringAsFixed(1)}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ]),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${fmtNum(q.last)}  ${fmtPct(q.changePct)}',
                  style: TextStyle(color: changeColor(q.change))),
              Text('${fmtCompact(q.value)} ج.م', style: const TextStyle(fontSize: 13)),
            ]),
            Text('حجم ${fmtCompact(q.volume)} مقابل متوسط ${fmtCompact(q.avgVolume!)}',
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            Text(_read(q), style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}
